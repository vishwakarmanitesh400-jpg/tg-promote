package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.TgPromoteDao
import com.example.data.local.UserEntity
import com.example.data.local.ChannelEntity
import com.example.data.local.CampaignEntity
import com.example.data.local.PaymentEntity
import com.example.data.local.PointTransactionEntity
import com.example.data.local.WithdrawalEntity
import com.example.data.local.ReferralEntity
import com.example.data.local.ReportEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.SettingsEntity
import com.example.data.repository.TgPromoteRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

class FakeTgPromoteDao : TgPromoteDao {
    override suspend fun insertUser(user: UserEntity) {}
    override suspend fun updateUser(user: UserEntity) {}
    override fun getUser(userId: String): Flow<UserEntity?> = flowOf(null)
    override suspend fun getUserSync(userId: String): UserEntity? = null
    override fun getAllUsers(): Flow<List<UserEntity>> = flowOf(emptyList())

    override suspend fun insertChannel(channel: ChannelEntity) {}
    override suspend fun updateChannel(channel: ChannelEntity) {}
    override suspend fun getChannelById(id: String): ChannelEntity? = null
    override suspend fun getChannelByUsername(username: String): ChannelEntity? = null
    override fun getAllChannels(): Flow<List<ChannelEntity>> = flowOf(emptyList())
    override fun getApprovedChannels(): Flow<List<ChannelEntity>> = flowOf(emptyList())

    override suspend fun insertCampaign(campaign: CampaignEntity) {}
    override suspend fun updateCampaign(campaign: CampaignEntity) {}
    override fun getActiveCampaigns(): Flow<List<CampaignEntity>> = flowOf(emptyList())
    override fun getUserCampaigns(userId: String): Flow<List<CampaignEntity>> = flowOf(emptyList())
    override fun getAllCampaigns(): Flow<List<CampaignEntity>> = flowOf(emptyList())
    override suspend fun getCampaignById(id: String): CampaignEntity? = null
    override fun getCampaignFlow(id: String): Flow<CampaignEntity?> = flowOf(null)

    override suspend fun insertPayment(payment: PaymentEntity) {}
    override suspend fun updatePayment(payment: PaymentEntity) {}
    override suspend fun getPaymentByOrderId(orderId: String): PaymentEntity? = null
    override fun getAllPayments(): Flow<List<PaymentEntity>> = flowOf(emptyList())
    override fun getUserPayments(userId: String): Flow<List<PaymentEntity>> = flowOf(emptyList())

    override suspend fun insertPointTransaction(pointTx: PointTransactionEntity) {}
    override fun getUserPointsTransactions(userId: String): Flow<List<PointTransactionEntity>> = flowOf(emptyList())
    override suspend fun getUserActionCountSince(userId: String, action: String, sinceTimestamp: Long): List<PointTransactionEntity> = emptyList()

    override suspend fun insertWithdrawal(withdrawal: WithdrawalEntity) {}
    override suspend fun updateWithdrawal(withdrawal: WithdrawalEntity) {}
    override suspend fun getWithdrawalById(id: String): WithdrawalEntity? = null
    override fun getUserWithdrawals(userId: String): Flow<List<WithdrawalEntity>> = flowOf(emptyList())
    override fun getAllWithdrawals(): Flow<List<WithdrawalEntity>> = flowOf(emptyList())

    override suspend fun insertReferral(referral: ReferralEntity) {}
    override fun getUserReferrals(userId: String): Flow<List<ReferralEntity>> = flowOf(emptyList())

    override suspend fun insertReport(report: ReportEntity) {}
    override suspend fun updateReport(report: ReportEntity) {}
    override fun getAllReports(): Flow<List<ReportEntity>> = flowOf(emptyList())

    override suspend fun insertAuditLog(log: AuditLogEntity) {}
    override fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = flowOf(emptyList())

    override suspend fun insertSettings(settings: SettingsEntity) {}
    override fun getSettings(): Flow<SettingsEntity?> = flowOf(null)
    override suspend fun getSettingsSync(): SettingsEntity? = null
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("TG Promote", appName)
    }

    @Test
    fun `validate telegram links accurately`() {
        val fakeDao = FakeTgPromoteDao()
        val repository = TgPromoteRepository(fakeDao)

        // Valid link formats
        val res1 = repository.validateTelegramLink("https://t.me/techalerts_india")
        assertTrue(res1.isValid)
        assertEquals("techalerts_india", res1.cleanUsername)
        assertEquals("https://t.me/techalerts_india", res1.canonicalUrl)

        val res2 = repository.validateTelegramLink("@crypto_pulse")
        assertTrue(res2.isValid)
        assertEquals("crypto_pulse", res2.cleanUsername)

        val res3 = repository.validateTelegramLink("t.me/daily_gk_india")
        assertTrue(res3.isValid)
        assertEquals("daily_gk_india", res3.cleanUsername)

        // Private links should be rejected with friendly explanation
        val resPrivate = repository.validateTelegramLink("https://t.me/joinchat/AAAAAFExample")
        assertFalse(resPrivate.isValid)
        assertTrue(resPrivate.errorMessage?.contains("Private invite links") == true)

        // Empty link
        val resEmpty = repository.validateTelegramLink("")
        assertFalse(resEmpty.isValid)
    }

    @Test
    fun `promotion packages have transparent pricing and duration`() {
        val fakeDao = FakeTgPromoteDao()
        val repository = TgPromoteRepository(fakeDao)
        val packages = repository.getPromotionPackages()

        assertEquals(3, packages.size)
        val basic = packages.find { it.id == "pkg_basic" }
        assertNotNull(basic)
        assertEquals(100.0, basic!!.priceInr, 0.01)
        assertEquals(3, basic.durationDays)

        val standard = packages.find { it.id == "pkg_standard" }
        assertNotNull(standard)
        assertEquals(500.0, standard!!.priceInr, 0.01)
        assertEquals(7, standard.durationDays)
        assertTrue(standard.isPopular)

        val premium = packages.find { it.id == "pkg_premium" }
        assertNotNull(premium)
        assertEquals(1000.0, premium!!.priceInr, 0.01)
        assertEquals(14, premium.durationDays)
    }
}

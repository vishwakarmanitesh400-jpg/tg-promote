package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.util.AppStrings
import com.example.ui.viewmodel.TgPromoteViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: TgPromoteViewModel,
    lang: String,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val allCampaigns by viewModel.allCampaigns.collectAsState()
    val allChannels by viewModel.allChannels.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allWithdrawals by viewModel.allWithdrawals.collectAsState()
    val allReports by viewModel.allReports.collectAsState()
    val allAuditLogs by viewModel.allAuditLogs.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val settings by viewModel.platformSettings.collectAsState()

    var selectedTab by remember { mutableStateOf("Financials") }
    val tabs = listOf("Financials", "Campaigns", "Channels", "Withdrawals", "Payments", "Audit Logs", "Settings")

    // Financial calculations
    val successfulPayments = allPayments.filter { it.status == "successful" }
    val refundedPayments = allPayments.filter { it.status == "refunded" }
    val grossRevenue = successfulPayments.sumOf { it.amount }
    val gatewayFees = grossRevenue * (settings.gatewayFeePercent / 100.0)
    val totalRefunds = refundedPayments.sumOf { it.amount }
    val totalUnredeemedPoints = allUsers.sumOf { it.pointsBalance }
    val userRewardLiability = totalUnredeemedPoints.toDouble() / settings.pointsPerInr.toDouble()
    val netPlatformRevenue = (grossRevenue - gatewayFees - totalRefunds - userRewardLiability).coerceAtLeast(0.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = AmberWarning)
                        Text("Owner / Admin Console", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.logoutAdmin(); onBack() }) {
                        Icon(Icons.Filled.Lock, contentDescription = "Lock", tint = CrimsonError)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Horizontal Navigation Tabs
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tabs) { tab ->
                    val isSelected = selectedTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        label = { Text(tab, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TelegramBlue,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            // Main Tab Content
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTab) {
                    "Financials" -> {
                        item {
                            FinancialOverviewSection(
                                grossRevenue = grossRevenue,
                                gatewayFees = gatewayFees,
                                totalRefunds = totalRefunds,
                                userRewardLiability = userRewardLiability,
                                netPlatformRevenue = netPlatformRevenue,
                                successfulCount = successfulPayments.size,
                                gatewayFeePercent = settings.gatewayFeePercent
                            )
                        }
                    }
                    "Campaigns" -> {
                        item {
                            Text(
                                text = "All Advertised Campaigns (${allCampaigns.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        items(allCampaigns) { camp ->
                            AdminCampaignItem(
                                campaign = camp,
                                onPause = { viewModel.adminPauseCampaign(camp.id) },
                                onResume = { viewModel.adminResumeCampaign(camp.id) }
                            )
                        }
                    }
                    "Channels" -> {
                        item {
                            Text(
                                text = "Registered Channels Moderation (${allChannels.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        items(allChannels) { chan ->
                            AdminChannelItem(
                                channel = chan,
                                onApprove = { viewModel.adminApproveChannel(chan.id) },
                                onReject = { viewModel.adminRejectChannel(chan.id, "Violation of promotional policies") }
                            )
                        }
                    }
                    "Withdrawals" -> {
                        item {
                            Text(
                                text = "User Withdrawal Requests Queue (${allWithdrawals.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        items(allWithdrawals) { wdr ->
                            AdminWithdrawalItem(
                                withdrawal = wdr,
                                onApprove = { viewModel.adminApproveWithdrawal(wdr.id) },
                                onReject = { viewModel.adminRejectWithdrawal(wdr.id, "Automated high-velocity activity detected") }
                            )
                        }
                    }
                    "Payments" -> {
                        item {
                            Text(
                                text = "Payment Gateway Transactions (${allPayments.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        items(allPayments) { pay ->
                            AdminPaymentItem(
                                payment = pay,
                                onRefund = {
                                    viewModel.adminRefundOrder(pay.orderId) {}
                                }
                            )
                        }
                    }
                    "Audit Logs" -> {
                        item {
                            Text(
                                text = "Immutable System Audit Trail (${allAuditLogs.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        items(allAuditLogs) { log ->
                            AdminAuditLogItem(log = log)
                        }
                    }
                    "Settings" -> {
                        item {
                            AdminSettingsSection(
                                settings = settings,
                                onSave = { viewModel.adminUpdateSettings(it) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FinancialOverviewSection(
    grossRevenue: Double,
    gatewayFees: Double,
    totalRefunds: Double,
    userRewardLiability: Double,
    netPlatformRevenue: Double,
    successfulCount: Int,
    gatewayFeePercent: Double
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Hero Net Revenue Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Estimated Net Platform Revenue",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "₹${"%.2f".format(netPlatformRevenue)}",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MintGreen
                )
                Text(
                    text = "Calculated in real-time from verified merchant payments minus gateway fees, processed refunds, and outstanding reward liabilities.",
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Ledger Breakdown Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Merchant Financial Ledger",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                SummaryRow("Gross Advertiser Payments ($successfulCount paid orders)", "₹${"%.2f".format(grossRevenue)}")
                SummaryRow("Payment Gateway Fee (${gatewayFeePercent}%)", "- ₹${"%.2f".format(gatewayFees)}")
                SummaryRow("Refunds Processed", "- ₹${"%.2f".format(totalRefunds)}")
                SummaryRow("User Reward Liability (Unredeemed TGP)", "- ₹${"%.2f".format(userRewardLiability)}")
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                SummaryRow("Net Realized Revenue", "₹${"%.2f".format(netPlatformRevenue)}", isHighlight = true)
            }
        }

        // Settlement Escrow Badge
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MintGreenContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MintGreen, modifier = Modifier.size(24.dp))
                Column {
                    Text(
                        text = "Owner Merchant Direct Settlement Active",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF065F46)
                    )
                    Text(
                        text = "All campaign orders are captured directly into the platform owner's verified merchant escrow. Payouts to genuine users are deducted via verified bank/UPI rails.",
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        color = Color(0xFF047857)
                    )
                }
            }
        }
    }
}

@Composable
fun AdminCampaignItem(
    campaign: Campaign,
    onPause: () -> Unit,
    onResume: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ID: ${campaign.id} • ${campaign.packageName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = campaign.status.uppercase(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (campaign.status == "active") MintGreen else AmberWarning
                )
            }
            Text(
                text = "Budget: ₹${campaign.budget.roundToInt()} | Spent: ₹${"%.2f".format(campaign.spent)} | Remaining: ₹${"%.2f".format(campaign.remaining)}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Stats: ${campaign.impressions} Impressions • ${campaign.views} Views • ${campaign.channelOpens} Opens",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.outline
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (campaign.status == "active") {
                    OutlinedButton(onClick = onPause, shape = RoundedCornerShape(8.dp)) {
                        Text("Pause", fontSize = 11.sp)
                    }
                } else if (campaign.status == "paused") {
                    Button(onClick = onResume, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = TelegramBlue)) {
                        Text("Resume", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminChannelItem(
    channel: TelegramChannel,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(channel.avatarEmoji, fontSize = 20.sp)
                    Column {
                        Text(channel.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("@${channel.username}", fontSize = 12.sp, color = TelegramBlue)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (channel.status == "approved") MintGreenContainer else CrimsonContainer
                ) {
                    Text(
                        text = channel.status.uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = if (channel.status == "approved") Color(0xFF065F46) else CrimsonError,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Text(
                text = channel.description,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (channel.status != "approved") {
                    Button(onClick = onApprove, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = MintGreen)) {
                        Text("Approve", fontSize = 11.sp)
                    }
                }
                if (channel.status != "rejected") {
                    OutlinedButton(onClick = onReject, shape = RoundedCornerShape(8.dp)) {
                        Text("Reject / Suspend", fontSize = 11.sp, color = CrimsonError)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminWithdrawalItem(
    withdrawal: Withdrawal,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.US)
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "₹${withdrawal.amountInr.roundToInt()} via ${withdrawal.payoutMethod}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = withdrawal.status.uppercase(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (withdrawal.status == "paid") MintGreen else AmberWarning
                )
            }
            Text(
                text = "Payout Details: ${withdrawal.payoutDetails}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Points: ${withdrawal.pointsDeducted} TGP • Requested: ${dateFormat.format(Date(withdrawal.createdAt))}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.outline
            )

            if (withdrawal.status == "pending" || withdrawal.status == "under_review") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onApprove,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MintGreen)
                    ) {
                        Text("Approve & Mark Paid", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = onReject,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Reject", fontSize = 11.sp, color = CrimsonError)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminPaymentItem(
    payment: Payment,
    onRefund: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.US)
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "₹${payment.amount.roundToInt()} (${payment.paymentMethod})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = payment.status.uppercase(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (payment.status == "successful") MintGreen else CrimsonError
                )
            }
            Text(
                text = "Order: ${payment.orderId} • Gateway Tx: ${payment.gatewayTransactionId}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Time: ${dateFormat.format(Date(payment.timestamp))}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.outline
            )

            if (payment.status == "successful") {
                OutlinedButton(
                    onClick = onRefund,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Issue Refund", fontSize = 11.sp, color = CrimsonError)
                }
            }
        }
    }
}

@Composable
fun AdminAuditLogItem(log: AuditLog) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.US)
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = log.action,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TelegramBlue
                )
                Text(
                    text = dateFormat.format(Date(log.timestamp)),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }
            Text(
                text = log.details,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Actor: ${log.adminId} • Target: ${log.targetId}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AdminSettingsSection(
    settings: PlatformSettings,
    onSave: (PlatformSettings) -> Unit
) {
    var pointsPerInr by remember { mutableStateOf(settings.pointsPerInr.toString()) }
    var minWithdrawal by remember { mutableStateOf(settings.minWithdrawalInr.roundToInt().toString()) }
    var viewReward by remember { mutableStateOf(settings.viewRewardPoints.toString()) }
    var openReward by remember { mutableStateOf(settings.openRewardPoints.toString()) }
    var referralReward by remember { mutableStateOf(settings.referralRewardPoints.toString()) }
    var dailyMax by remember { mutableStateOf(settings.dailyMaxPoints.toString()) }
    var gatewayFee by remember { mutableStateOf(settings.gatewayFeePercent.toString()) }
    var isSaved by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Platform Economy Controls",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            OutlinedTextField(
                value = pointsPerInr,
                onValueChange = { pointsPerInr = it },
                label = { Text("Points per ₹1 INR (Default: 100)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
                value = minWithdrawal,
                onValueChange = { minWithdrawal = it },
                label = { Text("Minimum Withdrawal in INR (Default: 100)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
                value = viewReward,
                onValueChange = { viewReward = it },
                label = { Text("Reward per Channel View in TGP (Default: 2)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
                value = openReward,
                onValueChange = { openReward = it },
                label = { Text("Reward per Open in Telegram in TGP (Default: 3)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
                value = referralReward,
                onValueChange = { referralReward = it },
                label = { Text("Referral Bonus in TGP (Default: 50)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
                value = dailyMax,
                onValueChange = { dailyMax = it },
                label = { Text("Daily Max Points Cap per User (Default: 100)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            OutlinedTextField(
                value = gatewayFee,
                onValueChange = { gatewayFee = it },
                label = { Text("Payment Gateway Fee % (Default: 2.5%)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            Button(
                onClick = {
                    val updated = settings.copy(
                        pointsPerInr = pointsPerInr.toIntOrNull() ?: settings.pointsPerInr,
                        minWithdrawalInr = minWithdrawal.toDoubleOrNull() ?: settings.minWithdrawalInr,
                        viewRewardPoints = viewReward.toIntOrNull() ?: settings.viewRewardPoints,
                        openRewardPoints = openReward.toIntOrNull() ?: settings.openRewardPoints,
                        referralRewardPoints = referralReward.toIntOrNull() ?: settings.referralRewardPoints,
                        dailyMaxPoints = dailyMax.toIntOrNull() ?: settings.dailyMaxPoints,
                        gatewayFeePercent = gatewayFee.toDoubleOrNull() ?: settings.gatewayFeePercent
                    )
                    onSave(updated)
                    isSaved = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TelegramBlue)
            ) {
                Text("Save Platform Configuration", fontWeight = FontWeight.Bold)
            }

            if (isSaved) {
                Text("Configuration updated successfully!", color = MintGreen, fontSize = 12.sp)
            }
        }
    }
}

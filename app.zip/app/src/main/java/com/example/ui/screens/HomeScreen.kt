package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Campaign
import com.example.data.model.TelegramChannel
import com.example.ui.theme.*
import com.example.ui.util.AppStrings
import com.example.ui.viewmodel.TgPromoteViewModel
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    viewModel: TgPromoteViewModel,
    lang: String,
    onNavigateToPromote: (String) -> Unit,
    onNavigateToCampaignAnalytics: (String) -> Unit,
    onNavigateToExplore: () -> Unit
) {
    val inputLink by viewModel.inputLink.collectAsState()
    val validationResult by viewModel.validationResult.collectAsState()
    val userCampaigns by viewModel.userCampaigns.collectAsState()
    val exploreCampaigns by viewModel.exploreCampaigns.collectAsState()

    // Aggregate statistics
    val activeCampaignsCount = userCampaigns.count { it.first.status == "active" }
    val totalViews = userCampaigns.sumOf { it.first.views }
    val totalOpens = userCampaigns.sumOf { it.first.channelOpens }
    val totalClicks = userCampaigns.sumOf { it.first.voluntaryClicks }
    val totalRemainingBalance = userCampaigns.sumOf { it.first.remaining }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Promo Box: Paste Telegram Link
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(TelegramBlue, TelegramBlueDark)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.RocketLaunch,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = AppStrings.get("app_name", lang),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = AppStrings.get("tagline", lang),
                                fontSize = 13.sp,
                                color = TelegramBlue,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Text(
                        text = "Paste your Telegram public channel link to launch instant, genuine promotion to real users.",
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Link Input Field
                    OutlinedTextField(
                        value = inputLink,
                        onValueChange = { viewModel.onLinkInputChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_channel_link_input"),
                        placeholder = {
                            Text(
                                "https://t.me/channelname or @channelname",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Filled.Link,
                                contentDescription = "Link",
                                tint = TelegramBlue
                            )
                        },
                        trailingIcon = {
                            if (inputLink.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onLinkInputChanged("") }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true
                    )

                    // Validation Feedback Preview
                    if (validationResult != null) {
                        val res = validationResult!!
                        if (res.isValid) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MintGreenContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(text = res.avatarEmoji, fontSize = 22.sp)
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = res.titleEstimate,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color(0xFF065F46)
                                        )
                                        Text(
                                            text = "@${res.cleanUsername} • ${res.categoryEstimate}",
                                            fontSize = 12.sp,
                                            color = Color(0xFF047857)
                                        )
                                    }
                                    Icon(
                                        Icons.Filled.CheckCircle,
                                        contentDescription = "Valid",
                                        tint = MintGreen,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        } else if (res.errorMessage != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = CrimsonContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.Error,
                                        contentDescription = "Error",
                                        tint = CrimsonError,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = res.errorMessage,
                                        fontSize = 12.sp,
                                        color = CrimsonError
                                    )
                                }
                            }
                        }
                    }

                    // Start Promotion CTA Button
                    Button(
                        onClick = {
                            if (validationResult?.isValid == true) {
                                onNavigateToPromote(inputLink)
                            } else {
                                onNavigateToPromote("")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("home_start_promotion_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TelegramBlue
                        )
                    ) {
                        Icon(
                            Icons.Filled.RocketLaunch,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppStrings.get("start_promotion", lang),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 2. Real Growth Policy Transparency Badge
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Filled.VerifiedUser,
                        contentDescription = "Verified",
                        tint = TelegramBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "Genuine Telegram Marketplace",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Zero bot subscribers, no forced joins, no OTP requests. Users voluntarily discover and join your channel.",
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // 3. Live Dashboard Analytics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Live Campaign Metrics",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = AppStrings.get("active_campaigns", lang),
                        value = "$activeCampaignsCount",
                        icon = Icons.Filled.Campaign,
                        iconTint = TelegramBlue,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = AppStrings.get("campaign_views", lang),
                        value = "$totalViews",
                        icon = Icons.Filled.Visibility,
                        iconTint = MintGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = AppStrings.get("channel_opens", lang),
                        value = "$totalOpens",
                        icon = Icons.Filled.OpenInNew,
                        iconTint = RoyalIndigo,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = AppStrings.get("promotional_clicks", lang),
                        value = "$totalClicks",
                        icon = Icons.Filled.TouchApp,
                        iconTint = AmberWarning,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Balance summary card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MintGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Filled.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = MintGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = AppStrings.get("campaign_balance", lang),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "₹${"%.2f".format(totalRemainingBalance)} Remaining",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        TextButton(onClick = onNavigateToExplore) {
                            Text("Explore Feed", fontWeight = FontWeight.SemiBold)
                            Icon(Icons.Filled.ChevronRight, contentDescription = null)
                        }
                    }
                }
            }
        }

        // 4. Recent Campaigns Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.get("recent_campaigns", lang),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${userCampaigns.size} Total",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 5. Recent Campaigns List
        if (userCampaigns.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Outlined.Campaign,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(44.dp)
                        )
                        Text(
                            text = "No campaigns yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Paste your channel link above to launch your first verified campaign!",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(userCampaigns) { (campaign, channel) ->
                CampaignCardItem(
                    campaign = campaign,
                    channel = channel,
                    lang = lang,
                    onClick = { onNavigateToCampaignAnalytics(campaign.id) }
                )
            }
        }
    }
}

@Composable
fun MetricStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Icon(
                    icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun CampaignCardItem(
    campaign: Campaign,
    channel: TelegramChannel,
    lang: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("campaign_card_${campaign.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = channel.avatarEmoji, fontSize = 24.sp)
                    Column {
                        Text(
                            text = channel.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "@${channel.username}",
                            fontSize = 12.sp,
                            color = TelegramBlue
                        )
                    }
                }

                // Status Pill
                val (statusText, statusBg, statusColor) = when (campaign.status) {
                    "active" -> Triple("🟢 ACTIVE", MintGreenContainer, Color(0xFF047857))
                    "paused" -> Triple("⏸️ PAUSED", AmberContainer, Color(0xFFB45309))
                    else -> Triple("🏁 COMPLETED", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusBg
                ) {
                    Text(
                        text = statusText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Budget Progress
            val progress = if (campaign.budget > 0) (campaign.spent / campaign.budget).toFloat() else 0f
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Spent ₹${campaign.spent.roundToInt()} of ₹${campaign.budget.roundToInt()}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Remaining ₹${campaign.remaining.roundToInt()}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = TelegramBlue,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Filled.Visibility, contentDescription = null, tint = MintGreen, modifier = Modifier.size(14.dp))
                        Text("${campaign.views} Views", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Filled.OpenInNew, contentDescription = null, tint = TelegramBlue, modifier = Modifier.size(14.dp))
                        Text("${campaign.channelOpens} Opens", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onClick() }
                ) {
                    Text(
                        text = "Analytics",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TelegramBlue
                    )
                    Icon(
                        Icons.Filled.ChevronRight,
                        contentDescription = null,
                        tint = TelegramBlue,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

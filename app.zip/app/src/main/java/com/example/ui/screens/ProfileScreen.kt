package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.util.AppStrings
import com.example.ui.viewmodel.TgPromoteViewModel

@Composable
fun ProfileScreen(
    viewModel: TgPromoteViewModel,
    lang: String,
    onNavigateToAdmin: () -> Unit,
    onNavigateToWithdraw: () -> Unit,
    onNavigateToReferral: () -> Unit,
    onShowTerms: () -> Unit,
    onShowPrivacy: () -> Unit
) {
    val user by viewModel.currentUser.collectAsState()
    val isAdminAuth by viewModel.isAdminAuthenticated.collectAsState()
    var showAdminPinDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Profile Header Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(TelegramBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user?.name?.take(1) ?: "U",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = user?.name ?: "Advertiser",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (user?.role == "admin") AmberContainer else MintGreenContainer
                            ) {
                                Text(
                                    text = if (user?.role == "admin") "OWNER" else "ADVERTISER",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (user?.role == "admin") Color(0xFFB45309) else Color(0xFF047857),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = user?.email ?: "user@example.com",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "@${user?.telegramUsername ?: "telegram_user"}",
                            fontSize = 12.sp,
                            color = TelegramBlue,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Language Switcher: Hindi + English
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Language / भाषा",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = lang == "en",
                            onClick = { viewModel.setLanguage("en") },
                            label = { Text("English (US)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TelegramBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("lang_en_chip")
                        )
                        FilterChip(
                            selected = lang == "hi",
                            onClick = { viewModel.setLanguage("hi") },
                            label = { Text("हिंदी (Hindi)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TelegramBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("lang_hi_chip")
                        )
                    }
                }
            }
        }

        // Quick Navigation Links
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    ProfileMenuRow(
                        icon = Icons.Filled.AccountBalanceWallet,
                        title = "Rewards Wallet & Payouts",
                        subtitle = "${user?.pointsBalance ?: 0} TGP Available",
                        onClick = onNavigateToWithdraw
                    )
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    ProfileMenuRow(
                        icon = Icons.Filled.CardGiftcard,
                        title = "Referral Program",
                        subtitle = "Share code: ${user?.referralCode ?: ""}",
                        onClick = onNavigateToReferral
                    )
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    ProfileMenuRow(
                        icon = Icons.Filled.Description,
                        title = "Terms & Promotion Policies",
                        subtitle = "Genuine placement guidelines",
                        onClick = onShowTerms
                    )
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    ProfileMenuRow(
                        icon = Icons.Filled.PrivacyTip,
                        title = "Privacy Policy",
                        subtitle = "Data handling & zero-bot standards",
                        onClick = onShowPrivacy
                    )
                }
            }
        }

        // Switch Account for Testing (Advertiser vs Owner/Admin)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Switch Account Role (Demo)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.switchUserMode("user") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Advertiser Account", fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                viewModel.switchUserMode("admin")
                                onNavigateToAdmin()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TelegramBlue),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Platform Owner", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Platform Owner / Admin Access
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = TelegramDeepNavy
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Platform Owner & Admin Portal",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "Access owner revenue ledgers, channel approvals, campaign controls, withdrawal payouts, and system audit logs.",
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )

                    Button(
                        onClick = {
                            if (isAdminAuth) {
                                onNavigateToAdmin()
                            } else {
                                showAdminPinDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_admin_access_button")
                    ) {
                        Text(
                            text = if (isAdminAuth) "Open Owner Dashboard" else "Unlock Owner Panel (PIN)",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }
        }
    }

    // Admin PIN Dialog
    if (showAdminPinDialog) {
        AlertDialog(
            onDismissRequest = { showAdminPinDialog = false },
            title = { Text("Owner Verification", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter Owner/Admin PIN to manage revenue, campaigns, and user moderation (Demo PIN: admin123 or 8899)",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { pinInput = it },
                        placeholder = { Text("Enter PIN") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_pin_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                    if (pinError) {
                        Text("Incorrect PIN. Please try again.", color = CrimsonError, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (viewModel.authenticateAdmin(pinInput.trim())) {
                            showAdminPinDialog = false
                            pinInput = ""
                            pinError = false
                            onNavigateToAdmin()
                        } else {
                            pinError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TelegramBlue),
                    modifier = Modifier.testTag("admin_pin_submit")
                ) {
                    Text("Unlock")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdminPinDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProfileMenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = TelegramBlue, modifier = Modifier.size(22.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(18.dp))
    }
}

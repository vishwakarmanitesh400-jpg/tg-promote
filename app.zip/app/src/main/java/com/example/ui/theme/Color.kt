package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Telegram Sky / Electric Blue
val TelegramBlue = Color(0xFF0088CC)
val TelegramBlueDark = Color(0xFF0077B6)
val TelegramDeepNavy = Color(0xFF0B132B)
val TelegramNavySurface = Color(0xFF131C31)
val TelegramNavyCard = Color(0xFF1C2740)

// Accents
val MintGreen = Color(0xFF10B981)
val MintGreenContainer = Color(0xFFD1FAE5)
val AmberWarning = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)
val CrimsonError = Color(0xFFEF4444)
val CrimsonContainer = Color(0xFFFEE2E2)
val RoyalIndigo = Color(0xFF4361EE)

// Light Palette
val LightPrimary = Color(0xFF0077B6)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFE0F2FE)
val LightOnPrimaryContainer = Color(0xFF001F3F)

val LightSecondary = Color(0xFF3B82F6)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFDBEAFE)
val LightOnSecondaryContainer = Color(0xFF1E3A8A)

val LightTertiary = Color(0xFF0D9488)
val LightOnTertiary = Color(0xFFFFFFFF)

val LightBackground = Color(0xFFF8FAFC)
val LightOnBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Dark Palette
val DarkPrimary = Color(0xFF38BDF8)
val DarkOnPrimary = Color(0xFF082F49)
val DarkPrimaryContainer = Color(0xFF0C4A6E)
val DarkOnPrimaryContainer = Color(0xFFBAE6FD)

val DarkSecondary = Color(0xFF60A5FA)
val DarkOnSecondary = Color(0xFF172554)
val DarkSecondaryContainer = Color(0xFF1E3A8A)
val DarkOnSecondaryContainer = Color(0xFFBFDBFE)

val DarkTertiary = Color(0xFF2DD4BF)
val DarkOnTertiary = Color(0xFF042F2E)

val DarkBackground = Color(0xFF070B14)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkSurface = Color(0xFF0F172A)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

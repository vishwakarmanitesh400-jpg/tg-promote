package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TgPromoteDatabase
import com.example.data.model.*
import com.example.data.repository.TgPromoteRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class TgPromoteViewModel(application: Application) : AndroidViewModel(application) {

    private val database = TgPromoteDatabase.getDatabase(application, viewModelScope)
    val repository = TgPromoteRepository(database.dao())

    // Language state: "en" for English, "hi" for Hindi
    private val _currentLanguage = MutableStateFlow("en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
    }

    // Current User State
    val currentUser: StateFlow<User?> = repository.getCurrentUser()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // User's own campaigns
    val userCampaigns: StateFlow<List<Pair<Campaign, TelegramChannel>>> = repository.getUserCampaigns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Explore Marketplace Campaigns Feed
    val exploreCampaigns: StateFlow<List<Pair<Campaign, TelegramChannel>>> = repository.getActivePromotionCampaigns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Platform Settings
    val platformSettings: StateFlow<PlatformSettings> = repository.getPlatformSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlatformSettings())

    // User Points History
    val pointsHistory: StateFlow<List<PointTransaction>> = repository.getUserPointsHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Withdrawals
    val userWithdrawals: StateFlow<List<Withdrawal>> = repository.getUserWithdrawals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Referrals
    val userReferrals: StateFlow<List<Referral>> = repository.getUserReferrals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Link Validation State for Promotion Flow
    private val _inputLink = MutableStateFlow("")
    val inputLink: StateFlow<String> = _inputLink.asStateFlow()

    private val _validationResult = MutableStateFlow<TgPromoteRepository.LinkValidationResult?>(null)
    val validationResult: StateFlow<TgPromoteRepository.LinkValidationResult?> = _validationResult.asStateFlow()

    private val _selectedPackage = MutableStateFlow<PromotionPackage?>(null)
    val selectedPackage: StateFlow<PromotionPackage?> = _selectedPackage.asStateFlow()

    private val _activeOrder = MutableStateFlow<TgPromoteRepository.PaymentInitiationResult?>(null)
    val activeOrder: StateFlow<TgPromoteRepository.PaymentInitiationResult?> = _activeOrder.asStateFlow()

    private val _activatedCampaign = MutableStateFlow<Campaign?>(null)
    val activatedCampaign: StateFlow<Campaign?> = _activatedCampaign.asStateFlow()

    private val _isPaymentProcessing = MutableStateFlow(false)
    val isPaymentProcessing: StateFlow<Boolean> = _isPaymentProcessing.asStateFlow()

    // Admin Flow States
    val allCampaigns: StateFlow<List<Campaign>> = repository.getAllCampaigns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allChannels: StateFlow<List<TelegramChannel>> = repository.getAllChannels()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<Payment>> = repository.getAllPayments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWithdrawals: StateFlow<List<Withdrawal>> = repository.getAllWithdrawals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReports: StateFlow<List<Report>> = repository.getAllReports()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<AuditLog>> = repository.getAllAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<User>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin Login state
    private val _isAdminAuthenticated = MutableStateFlow(false)
    val isAdminAuthenticated: StateFlow<Boolean> = _isAdminAuthenticated.asStateFlow()

    init {
        // Set default selected package
        _selectedPackage.value = repository.getPromotionPackages().find { it.isPopular }
            ?: repository.getPromotionPackages().firstOrNull()
    }

    fun onLinkInputChanged(newLink: String) {
        _inputLink.value = newLink
        if (newLink.trim().isNotEmpty()) {
            _validationResult.value = repository.validateTelegramLink(newLink)
        } else {
            _validationResult.value = null
        }
    }

    fun selectPackage(pkg: PromotionPackage) {
        _selectedPackage.value = pkg
    }

    fun preparePromotionOrder(onReady: () -> Unit) {
        val result = _validationResult.value ?: return
        if (!result.isValid) return
        val pkg = _selectedPackage.value ?: return

        viewModelScope.launch {
            val channel = repository.registerOrGetChannel(result)
            val order = repository.initiateOrder(channel, pkg)
            _activeOrder.value = order
            onReady()
        }
    }

    fun processPayment(
        paymentMethod: String,
        onSuccess: (Campaign) -> Unit,
        onError: (String) -> Unit
    ) {
        val order = _activeOrder.value ?: run {
            onError("No active order found")
            return
        }

        viewModelScope.launch {
            _isPaymentProcessing.value = true
            try {
                // Simulate verified server-side gateway processing & webhook confirmation
                kotlinx.coroutines.delay(1800)
                val campaign = repository.executePaymentAndActivateCampaign(
                    initiation = order,
                    paymentMethod = paymentMethod
                )
                _activatedCampaign.value = campaign
                _isPaymentProcessing.value = false
                _inputLink.value = ""
                _validationResult.value = null
                onSuccess(campaign)
            } catch (e: Exception) {
                _isPaymentProcessing.value = false
                onError(e.message ?: "Payment verification failed. Please try again.")
            }
        }
    }

    // Real User Action: Open Telegram Channel Link
    fun openChannelInTelegram(context: Context, channelUrl: String, campaignId: String?) {
        try {
            // Track channel view & open
            if (campaignId != null) {
                viewModelScope.launch {
                    val points = repository.recordChannelOpen(campaignId)
                    if (points > 0) {
                        Toast.makeText(context, "+$points TGP earned for genuine discovery!", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            // Launch Telegram Intent
            val uri = Uri.parse(channelUrl)
            val telegramIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(telegramIntent)
        } catch (e: Exception) {
            // Fallback to browser
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(channelUrl)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(browserIntent)
            } catch (e2: Exception) {
                Toast.makeText(context, "Could not open Telegram channel: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Track Preview View
    fun trackPromotionView(campaignId: String) {
        viewModelScope.launch {
            repository.recordChannelView(campaignId)
        }
    }

    // Submit Withdrawal
    fun submitWithdrawal(
        amountInr: Double,
        payoutMethod: String,
        payoutDetails: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.requestWithdrawal(amountInr, payoutMethod, payoutDetails)
            result.onSuccess {
                onSuccess()
            }.onFailure { error ->
                onError(error.message ?: "Failed to process withdrawal request.")
            }
        }
    }

    // Apply Referral
    fun applyReferral(code: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.applyReferralCode(code)
            res.onSuccess { msg ->
                onResult(true, msg)
            }.onFailure { err ->
                onResult(false, err.message ?: "Invalid referral code")
            }
        }
    }

    // Report Channel
    fun reportChannel(
        channel: TelegramChannel,
        reason: String,
        details: String,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            repository.submitReport(
                targetType = "channel",
                targetId = channel.id,
                targetName = "@${channel.username} (${channel.name})",
                reason = reason,
                details = details
            )
            onDone()
        }
    }

    // Admin Verification
    fun authenticateAdmin(pin: String): Boolean {
        if (pin == "admin123" || pin == "8899" || pin == "owner2026") {
            _isAdminAuthenticated.value = true
            return true
        }
        return false
    }

    fun logoutAdmin() {
        _isAdminAuthenticated.value = false
    }

    // Admin Actions
    fun adminApproveChannel(channelId: String) {
        viewModelScope.launch {
            repository.updateChannelStatus(channelId, "approved", "Approved by platform owner.")
        }
    }

    fun adminRejectChannel(channelId: String, reason: String) {
        viewModelScope.launch {
            repository.updateChannelStatus(channelId, "rejected", reason)
        }
    }

    fun adminPauseCampaign(campaignId: String) {
        viewModelScope.launch {
            repository.updateCampaignStatus(campaignId, "paused")
        }
    }

    fun adminResumeCampaign(campaignId: String) {
        viewModelScope.launch {
            repository.updateCampaignStatus(campaignId, "active")
        }
    }

    fun adminRefundOrder(orderId: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.refundPayment(orderId)
            onComplete(success)
        }
    }

    fun adminApproveWithdrawal(withdrawalId: String) {
        viewModelScope.launch {
            repository.updateWithdrawalStatus(withdrawalId, "paid")
        }
    }

    fun adminRejectWithdrawal(withdrawalId: String, reason: String) {
        viewModelScope.launch {
            repository.updateWithdrawalStatus(withdrawalId, "rejected", reason)
        }
    }

    fun adminUpdateSettings(settings: PlatformSettings) {
        viewModelScope.launch {
            repository.updatePlatformSettings(settings)
        }
    }

    // Switch between Advertiser demo and Admin demo
    fun switchUserMode(role: String) {
        if (role == "admin") {
            repository.switchUser("admin_owner_001")
            _isAdminAuthenticated.value = true
        } else {
            repository.switchUser("user_demo_101")
        }
    }
}

package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Withdrawal
import com.example.ui.theme.*
import com.example.ui.util.AppStrings
import com.example.ui.viewmodel.TgPromoteViewModel
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WithdrawalScreen(
    viewModel: TgPromoteViewModel,
    lang: String,
    onBack: () -> Unit
) {
    val user by viewModel.currentUser.collectAsState()
    val settings by viewModel.platformSettings.collectAsState()
    val withdrawals by viewModel.userWithdrawals.collectAsState()

    val availablePoints = user?.pointsBalance ?: 0
    val availableInr = availablePoints.toDouble() / settings.pointsPerInr.toDouble()

    var amountInput by remember { mutableStateOf("${settings.minWithdrawalInr.roundToInt()}") }
    var selectedMethod by remember { mutableStateOf("UPI") }
    var upiIdInput by remember { mutableStateOf("") }
    var bankAccountInput by remember { mutableStateOf("") }
    var bankIfscInput by remember { mutableStateOf("") }
    var bankNameInput by remember { mutableStateOf("") }

    var statusMessage by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Withdraw Rewards", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("withdraw_back_button")) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Balance Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Available to Redeem",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "₹${"%.2f".format(availableInr)}",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = MintGreen
                            )
                            Text(
                                text = "($availablePoints TGP)",
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "Conversion rate: ${settings.pointsPerInr} TGP = ₹1.00 • Minimum withdrawal: ₹${settings.minWithdrawalInr.roundToInt()}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Withdrawal Form
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Request Payout",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Amount Input
                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = { amountInput = it },
                            label = { Text("Amount (₹)", fontSize = 12.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("withdraw_amount_input"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        // Method selection: UPI vs Bank
                        Text("Payout Destination", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilterChip(
                                selected = selectedMethod == "UPI",
                                onClick = { selectedMethod = "UPI" },
                                label = { Text("UPI ID / VPA") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TelegramBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                            FilterChip(
                                selected = selectedMethod == "Bank Transfer",
                                onClick = { selectedMethod = "Bank Transfer" },
                                label = { Text("Bank Account") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TelegramBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }

                        if (selectedMethod == "UPI") {
                            OutlinedTextField(
                                value = upiIdInput,
                                onValueChange = { upiIdInput = it },
                                label = { Text("Your UPI ID", fontSize = 12.sp) },
                                placeholder = { Text("e.g. yourname@oksbi or phone@paytm") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("withdraw_upi_input"),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = bankNameInput,
                                    onValueChange = { bankNameInput = it },
                                    label = { Text("Account Holder Name", fontSize = 12.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = bankAccountInput,
                                    onValueChange = { bankAccountInput = it },
                                    label = { Text("Account Number", fontSize = 12.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = bankIfscInput,
                                    onValueChange = { bankIfscInput = it },
                                    label = { Text("IFSC Code", fontSize = 12.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true
                                )
                            }
                        }

                        // Submit Button
                        Button(
                            onClick = {
                                val amount = amountInput.toDoubleOrNull() ?: 0.0
                                val details = if (selectedMethod == "UPI") {
                                    upiIdInput
                                } else {
                                    "Name: $bankNameInput, A/C: $bankAccountInput, IFSC: $bankIfscInput"
                                }

                                isSubmitting = true
                                viewModel.submitWithdrawal(
                                    amountInr = amount,
                                    payoutMethod = selectedMethod,
                                    payoutDetails = details,
                                    onSuccess = {
                                        isSubmitting = false
                                        statusMessage = Pair(true, "Withdrawal request submitted successfully! Under review.")
                                        amountInput = ""
                                        upiIdInput = ""
                                    },
                                    onError = { err ->
                                        isSubmitting = false
                                        statusMessage = Pair(false, err)
                                    }
                                )
                            },
                            enabled = !isSubmitting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_withdrawal_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MintGreen)
                        ) {
                            Text("Submit Withdrawal Request", fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        // Status Banner
                        if (statusMessage != null) {
                            val (success, msg) = statusMessage!!
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (success) MintGreenContainer else CrimsonContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = msg,
                                    color = if (success) Color(0xFF065F46) else CrimsonError,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Withdrawal History
            item {
                Text(
                    text = "Withdrawal Requests History",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (withdrawals.isEmpty()) {
                item {
                    Text(
                        text = "No previous withdrawal requests found.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(withdrawals) { wdr ->
                    WithdrawalHistoryItem(wdr = wdr)
                }
            }
        }
    }
}

@Composable
fun WithdrawalHistoryItem(wdr: Withdrawal) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)
    val (statusLabel, statusBg, statusColor) = when (wdr.status) {
        "paid" -> Triple("🟢 PAID", MintGreenContainer, Color(0xFF047857))
        "approved" -> Triple("🟠 APPROVED", AmberContainer, Color(0xFFB45309))
        "rejected" -> Triple("🔴 REJECTED", CrimsonContainer, CrimsonError)
        else -> Triple("🟡 PENDING", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "₹${wdr.amountInr.roundToInt()} via ${wdr.payoutMethod}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusBg
                ) {
                    Text(
                        text = statusLabel,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Text(
                text = "Details: ${wdr.payoutDetails}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Requested: ${dateFormat.format(Date(wdr.createdAt))}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.outline
            )
            if (wdr.rejectionReason != null) {
                Text(
                    text = "Reason: ${wdr.rejectionReason}",
                    fontSize = 11.sp,
                    color = CrimsonError
                )
            }
        }
    }
}

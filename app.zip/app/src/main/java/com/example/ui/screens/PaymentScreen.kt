package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TgPromoteViewModel
import kotlin.math.roundToInt

@Composable
fun PaymentScreen(
    viewModel: TgPromoteViewModel,
    lang: String,
    onPaymentSuccess: (String) -> Unit,
    onCancel: () -> Unit
) {
    val activeOrder by viewModel.activeOrder.collectAsState()
    val isProcessing by viewModel.isPaymentProcessing.collectAsState()

    var selectedMethod by remember { mutableStateOf("UPI") }
    var selectedUpiApp by remember { mutableStateOf("Google Pay") }
    var customUpiId by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var selectedBank by remember { mutableStateOf("HDFC Bank") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val order = activeOrder
    if (order == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No active order found.")
        }
        return
    }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(onClick = onCancel, modifier = Modifier.testTag("payment_back_button")) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                    Column {
                        Text(
                            text = "Checkout & Activation",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Order ID: ${order.orderId}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Amount Payable",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "₹${order.amount.roundToInt()}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.processPayment(
                                    paymentMethod = selectedMethod,
                                    onSuccess = { campaign ->
                                        onPaymentSuccess(campaign.id)
                                    },
                                    onError = { err ->
                                        errorMessage = err
                                    }
                                )
                            },
                            enabled = !isProcessing,
                            modifier = Modifier
                                .height(52.dp)
                                .testTag("pay_securely_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MintGreen)
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verifying...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Pay ₹${order.amount.roundToInt()} Securely",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Owner Merchant Badge
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MintGreenContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MintGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Security, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Column {
                            Text(
                                text = "Owner Verified Merchant Account",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF065F46)
                            )
                            Text(
                                text = "Direct settlement into platform escrow. Campaign activates automatically upon payment confirmation.",
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                color = Color(0xFF047857)
                            )
                        }
                    }
                }
            }

            // Order Details Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Campaign Order Summary",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        SummaryRow("Channel", "${order.channel.name} (@${order.channel.username})")
                        SummaryRow("Promotion Package", order.pkg.name)
                        SummaryRow("Duration", "${order.pkg.durationDays} Days")
                        SummaryRow("Estimated Reach", "${order.pkg.estimatedReachMin} – ${order.pkg.estimatedReachMax} Views")
                        SummaryRow("Internal Order ID", order.orderId)
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        SummaryRow("Total Amount", "₹${order.amount.roundToInt()}", isHighlight = true)
                    }
                }
            }

            // Payment Methods Selection
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Select Payment Method",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // 1. UPI Option
                        PaymentMethodTab(
                            title = "UPI (Instant Activation)",
                            subtitle = "Google Pay, PhonePe, Paytm, BHIM, UPI ID",
                            icon = Icons.Filled.QrCodeScanner,
                            isSelected = selectedMethod == "UPI",
                            onClick = { selectedMethod = "UPI" }
                        )

                        AnimatedVisibility(visible = selectedMethod == "UPI") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 8.dp, top = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("Popular UPI Apps", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("Google Pay", "PhonePe", "Paytm", "BHIM").forEach { app ->
                                        val isChosen = selectedUpiApp == app
                                        FilterChip(
                                            selected = isChosen,
                                            onClick = { selectedUpiApp = app },
                                            label = { Text(app, fontSize = 11.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = TelegramBlue,
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                Text("Or Enter UPI VPA ID", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = customUpiId,
                                    onValueChange = { customUpiId = it },
                                    placeholder = { Text("e.g. mobile@upi or name@okaxis", fontSize = 12.sp) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("payment_upi_input"),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true
                                )
                            }
                        }

                        // 2. Cards Option
                        PaymentMethodTab(
                            title = "Credit / Debit Cards",
                            subtitle = "Visa, Mastercard, RuPay",
                            icon = Icons.Filled.CreditCard,
                            isSelected = selectedMethod == "Cards",
                            onClick = { selectedMethod = "Cards" }
                        )

                        AnimatedVisibility(visible = selectedMethod == "Cards") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 8.dp, top = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = cardNumber,
                                    onValueChange = { if (it.length <= 19) cardNumber = it },
                                    label = { Text("Card Number", fontSize = 12.sp) },
                                    placeholder = { Text("XXXX XXXX XXXX XXXX", fontSize = 12.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(
                                        value = cardExpiry,
                                        onValueChange = { if (it.length <= 5) cardExpiry = it },
                                        label = { Text("MM/YY", fontSize = 12.sp) },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = "",
                                        onValueChange = {},
                                        label = { Text("CVV", fontSize = 12.sp) },
                                        placeholder = { Text("•••", fontSize = 12.sp) },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true
                                    )
                                }
                                Text(
                                    text = "🔒 Your card credentials are encrypted and processed through payment gateway tokenization. The app never saves private card details.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // 3. Net Banking Option
                        PaymentMethodTab(
                            title = "Net Banking",
                            subtitle = "HDFC, ICICI, SBI, Axis & all Indian banks",
                            icon = Icons.Filled.AccountBalance,
                            isSelected = selectedMethod == "Net Banking",
                            onClick = { selectedMethod = "Net Banking" }
                        )

                        AnimatedVisibility(visible = selectedMethod == "Net Banking") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 8.dp, top = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("HDFC Bank", "State Bank of India", "ICICI Bank", "Axis Bank").forEach { bank ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedBank = bank }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = selectedBank == bank,
                                            onClick = { selectedBank = bank }
                                        )
                                        Text(bank, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Error Message Banner
            if (errorMessage != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CrimsonContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMessage!!,
                            color = CrimsonError,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Security Notes
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Filled.Verified, contentDescription = null, tint = MintGreen, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Zero Fraud & Automatic Activation",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "• Payments are routed directly to the verified platform owner account.\n• Idempotent server-side signature verification prevents duplicate charges.\n• Your campaign automatically enters the live promotion feed within 5 seconds of confirmation.",
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentMethodTab(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) TelegramBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
    val bgColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(width = if (isSelected) 2.dp else 1.dp, color = borderColor, shape = RoundedCornerShape(12.dp))
            .background(bgColor)
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (isSelected) TelegramBlue else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(24.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        RadioButton(
            selected = isSelected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = TelegramBlue)
        )
    }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MintGreen
import com.example.ui.theme.TelegramBlue
import com.example.ui.util.AppStrings

sealed class BottomNavRoute(
    val route: String,
    val titleKey: String,
    val selectedIcon: @Composable () -> Unit,
    val unselectedIcon: @Composable () -> Unit
) {
    object Home : BottomNavRoute(
        "home",
        "nav_home",
        { Icon(Icons.Filled.Home, contentDescription = "Home") },
        { Icon(Icons.Outlined.Home, contentDescription = "Home") }
    )
    object Explore : BottomNavRoute(
        "explore",
        "nav_explore",
        { Icon(Icons.Filled.Explore, contentDescription = "Explore") },
        { Icon(Icons.Outlined.Explore, contentDescription = "Explore") }
    )
    object Promote : BottomNavRoute(
        "promote",
        "nav_promote",
        { Icon(Icons.Filled.RocketLaunch, contentDescription = "Promote") },
        { Icon(Icons.Outlined.RocketLaunch, contentDescription = "Promote") }
    )
    object Rewards : BottomNavRoute(
        "rewards",
        "nav_rewards",
        { Icon(Icons.Filled.CardGiftcard, contentDescription = "Rewards") },
        { Icon(Icons.Outlined.CardGiftcard, contentDescription = "Rewards") }
    )
    object Profile : BottomNavRoute(
        "profile",
        "nav_profile",
        { Icon(Icons.Filled.Person, contentDescription = "Profile") },
        { Icon(Icons.Outlined.Person, contentDescription = "Profile") }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppHeader(
    title: String,
    lang: String,
    pointsBalance: Int,
    onPointsClick: () -> Unit,
    onAdminClick: () -> Unit,
    isAdmin: Boolean = false,
    showBackButton: Boolean = false,
    onBackClick: () -> Unit = {}
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(TelegramBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Send,
                        contentDescription = "TG Logo",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = AppStrings.get("tagline", lang),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        navigationIcon = {
            if (showBackButton) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("nav_back_button")
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        },
        actions = {
            // Points Capsule
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier
                    .padding(end = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onPointsClick() }
                    .testTag("header_points_badge")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        Icons.Filled.MonetizationOn,
                        contentDescription = "Points",
                        tint = MintGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "$pointsBalance TGP",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Admin Shield Icon
            IconButton(
                onClick = onAdminClick,
                modifier = Modifier.testTag("admin_shield_button")
            ) {
                Icon(
                    imageVector = if (isAdmin) Icons.Filled.AdminPanelSettings else Icons.Outlined.AdminPanelSettings,
                    contentDescription = "Admin Panel",
                    tint = if (isAdmin) TelegramBlue else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun AppBottomNavigation(
    currentRoute: String,
    lang: String,
    onNavigate: (String) -> Unit
) {
    val items = listOf(
        BottomNavRoute.Home,
        BottomNavRoute.Explore,
        BottomNavRoute.Promote,
        BottomNavRoute.Rewards,
        BottomNavRoute.Profile
    )

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        items.forEach { item ->
            val selected = currentRoute == item.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = {
                    if (selected) item.selectedIcon() else item.unselectedIcon()
                },
                label = {
                    Text(
                        text = AppStrings.get(item.titleKey, lang),
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                modifier = Modifier.testTag("nav_${item.route}")
            )
        }
    }
}

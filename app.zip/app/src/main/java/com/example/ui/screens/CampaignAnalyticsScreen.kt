package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Campaign
import com.example.data.model.TelegramChannel
import com.example.ui.theme.*
import com.example.ui.util.AppStrings
import com.example.ui.viewmodel.TgPromoteViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CampaignAnalyticsScreen(
    viewModel: TgPromoteViewModel,
    lang: String,
    campaignId: String,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var campaign by remember { mutableStateOf<Campaign?>(null) }
    var channel by remember { mutableStateOf<TelegramChannel?>(null) }

    LaunchedEffect(campaignId) {
        viewModel.repository.getCampaignFlow(campaignId).collect { camp ->
            campaign = camp
            if (camp != null) {
                channel = viewModel.repository.getCampaignChannel(camp.channelId)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Campaign Analytics",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("analytics_back_button")) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        val camp = campaign
        val chan = channel

        if (camp == null || chan == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = TelegramBlue)
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Channel Header Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = chan.avatarEmoji, fontSize = 26.sp)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = chan.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(Icons.Filled.Verified, contentDescription = null, tint = TelegramBlue, modifier = Modifier.size(16.dp))
                            }
                            Text(
                                text = "@${chan.username} • ${camp.packageName} Package",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Status Pill
                        val (statusText, statusBg, statusColor) = when (camp.status) {
                            "active" -> Triple("🟢 ACTIVE", MintGreenContainer, Color(0xFF047857))
                            "paused" -> Triple("⏸️ PAUSED", AmberContainer, Color(0xFFB45309))
                            else -> Triple("🏁 COMPLETED", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = statusBg
                        ) {
                            Text(
                                text = statusText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Key Performance Indicators Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Real Engagement Performance",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricStatCard(
                            title = "Marketplace Impressions",
                            value = "${camp.impressions}",
                            icon = Icons.Filled.Feed,
                            iconTint = TelegramBlue,
                            modifier = Modifier.weight(1f)
                        )
                        MetricStatCard(
                            title = "Promotion Views",
                            value = "${camp.views}",
                            icon = Icons.Filled.Visibility,
                            iconTint = MintGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    val ctr = if (camp.views > 0) ((camp.channelOpens.toDouble() / camp.views.toDouble()) * 100.0) else 0.0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricStatCard(
                            title = "Channel Opens (Clicks)",
                            value = "${camp.channelOpens}",
                            icon = Icons.Filled.OpenInNew,
                            iconTint = RoyalIndigo,
                            modifier = Modifier.weight(1f)
                        )
                        MetricStatCard(
                            title = "Open Rate (CTR)",
                            value = "${"%.1f".format(ctr)}%",
                            icon = Icons.Filled.TrendingUp,
                            iconTint = AmberWarning,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Campaign Financial Balance Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Budget & Expenditure",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        val progress = if (camp.budget > 0) (camp.spent / camp.budget).toFloat() else 0f
                        LinearProgressIndicator(
                            progress = { progress.coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = TelegramBlue,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Budget", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("₹${camp.budget.roundToInt()}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Spent", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("₹${"%.2f".format(camp.spent)}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TelegramBlue)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Remaining", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("₹${"%.2f".format(camp.remaining)}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MintGreen)
                            }
                        }
                    }
                }
            }

            // Dates & Duration
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Campaign Schedule",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)
                        SummaryRow("Launch Date", dateFormat.format(Date(camp.startDate)))
                        SummaryRow("End Date", dateFormat.format(Date(camp.endDate)))
                        SummaryRow("Target Audience", "${camp.targetCategory} Enthusiasts")
                    }
                }
            }

            // Transparency Notice
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.Info, contentDescription = null, tint = TelegramBlue, modifier = Modifier.size(20.dp))
                        Text(
                            text = "Voluntary Join Notice: Real users who tap 'Open in Telegram' choose voluntarily whether to join your channel. TG Promote does not force joins or employ fake accounts.",
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Controls: Pause / Resume Campaign
            item {
                if (camp.status == "active") {
                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch {
                                viewModel.adminPauseCampaign(camp.id)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Pause Campaign", fontWeight = FontWeight.SemiBold)
                    }
                } else if (camp.status == "paused") {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                viewModel.adminResumeCampaign(camp.id)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TelegramBlue)
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Resume Campaign", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

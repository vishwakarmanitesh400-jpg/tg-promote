package com.example.ui.util

object AppStrings {
    fun get(key: String, lang: String = "en"): String {
        val isHindi = lang == "hi"
        return when (key) {
            "app_name" -> if (isHindi) "टीजी प्रमोट" else "TG Promote"
            "tagline" -> if (isHindi) "अपना टेलीग्राम चैनल प्रमोट करें" else "Promote Your Telegram Channel"
            "paste_prompt" -> if (isHindi) "अपने टेलीग्राम चैनल का लिंक पेस्ट करें" else "Paste your Telegram channel link"
            "start_promotion" -> if (isHindi) "🚀 प्रमोशन शुरू करें" else "🚀 Start Promotion"
            "open_in_telegram" -> if (isHindi) "टेलीग्राम में खोलें" else "OPEN IN TELEGRAM"
            "active_campaigns" -> if (isHindi) "सक्रिय अभियान" else "Active Campaigns"
            "campaign_views" -> if (isHindi) "कुल अभियान दृश्य" else "Total Campaign Views"
            "channel_opens" -> if (isHindi) "चैनल ओपन" else "Channel Opens"
            "promotional_clicks" -> if (isHindi) "प्रमोशनल क्लिक्स" else "Promotional Clicks"
            "campaign_balance" -> if (isHindi) "अभियान शेष" else "Campaign Balance"
            "recent_campaigns" -> if (isHindi) "हाल के अभियान" else "Recent Campaigns"
            "packages_title" -> if (isHindi) "प्रमोशन पैकेज चुनें" else "Select Promotion Package"
            "estimated_reach" -> if (isHindi) "अनुमानित पहुंच" else "Estimated Reach"
            "duration" -> if (isHindi) "अवधि" else "Duration"
            "disclaimer_reach" -> if (isHindi) "अनुमानित पहुंच ऐतिहासिक अभियान प्रदर्शन पर आधारित है। सब्सक्राइबर संख्या की कोई गारंटी नहीं है।" else "Estimated reach based on historical campaign performance. Subscriber numbers are not guaranteed."
            "voluntary_join_notice" -> if (isHindi) "उपयोगकर्ता स्वेच्छा से निर्णय लेते हैं कि चैनल से जुड़ना है या नहीं। कोई बॉट या फेक अकाउंट नहीं।" else "Real users voluntarily decide whether to join your channel. Strictly genuine promotion."
            "campaign_active_badge" -> if (isHindi) "🟢 अभियान सक्रिय है" else "🟢 CAMPAIGN ACTIVE"
            "promotion_active" -> if (isHindi) "🟢 प्रमोशन सक्रिय" else "🟢 PROMOTION ACTIVE"
            "nav_home" -> if (isHindi) "होम" else "Home"
            "nav_explore" -> if (isHindi) "एक्सप्लोर" else "Explore"
            "nav_promote" -> if (isHindi) "प्रमोट" else "Promote"
            "nav_rewards" -> if (isHindi) "रिवॉर्ड्स" else "Rewards"
            "nav_profile" -> if (isHindi) "प्रोफाइल" else "Profile"
            "wallet_title" -> if (isHindi) "मेरा टीजी पॉइंट्स वॉलेट" else "My TG Points Wallet"
            "available_points" -> if (isHindi) "उपलब्ध पॉइंट्स" else "Available Points"
            "current_value" -> if (isHindi) "वर्तमान मूल्य" else "Current Value"
            "withdraw_points" -> if (isHindi) "पैसे निकालें" else "Withdraw Rewards"
            "min_withdrawal" -> if (isHindi) "न्यूनतम निकासी" else "Minimum Withdrawal"
            "referral_title" -> if (isHindi) "रेफरल प्रोग्राम" else "Refer & Earn"
            "referral_code" -> if (isHindi) "आपका रेफरल कोड" else "Your Referral Code"
            "admin_dashboard" -> if (isHindi) "मालिक / एडमिन पैनल" else "Owner / Admin Panel"
            "financial_overview" -> if (isHindi) "वित्तीय अवलोकन" else "Owner Financial Overview"
            "gross_revenue" -> if (isHindi) "सकल विज्ञापनदाता भुगतान" else "Gross Advertiser Payments"
            "gateway_fees" -> if (isHindi) "पेमेंट गेटवे शुल्क" else "Payment Gateway Fees"
            "refunds" -> if (isHindi) "रिफंड" else "Refunds"
            "reward_liability" -> if (isHindi) "उपयोगकर्ता रिवॉर्ड देनदारी" else "User Reward Allocation"
            "net_revenue" -> if (isHindi) "अनुमानित प्लेटफॉर्म राजस्व" else "Estimated Platform Revenue"
            "terms_policy" -> if (isHindi) "नियम एवं शर्तें" else "Terms & Policy"
            "report_channel" -> if (isHindi) "चैनल की रिपोर्ट करें" else "Report Channel"
            else -> key
        }
    }
}

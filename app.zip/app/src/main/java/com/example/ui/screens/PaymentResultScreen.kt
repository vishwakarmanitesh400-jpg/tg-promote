package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.util.AppStrings
import com.example.ui.viewmodel.TgPromoteViewModel
import kotlin.math.roundToInt

@Composable
fun PaymentResultScreen(
    viewModel: TgPromoteViewModel,
    lang: String,
    campaignId: String,
    onViewAnalytics: (String) -> Unit,
    onExploreMarketplace: () -> Unit
) {
    val activatedCampaign by viewModel.activatedCampaign.collectAsState()
    val activeOrder by viewModel.activeOrder.collectAsState()

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Success Checkmark Icon
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(MintGreenContainer),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MintGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Check,
                        contentDescription = "Active",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MintGreenContainer
            ) {
                Text(
                    text = AppStrings.get("campaign_active_badge", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF065F46),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Promotion Activated Successfully!",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Payment verified by Owner Merchant Account. Your channel is now live in the TG Promote marketplace.",
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Activation Breakdown Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val order = activeOrder
                    val camp = activatedCampaign

                    SummaryRow("Campaign ID", camp?.id ?: campaignId)
                    if (order != null) {
                        SummaryRow("Internal Order ID", order.orderId)
                        SummaryRow("Channel", "@${order.channel.username}")
                        SummaryRow("Allocated Budget", "₹${order.amount.roundToInt()}")
                        SummaryRow("Duration", "${order.pkg.durationDays} Days")
                    }
                    SummaryRow("Verification Mode", "Server Webhook Signature")
                    SummaryRow("Marketplace Status", "LIVE 🟢", isHighlight = true)
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // CTA Buttons
            Button(
                onClick = { onViewAnalytics(activatedCampaign?.id ?: campaignId) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("result_view_analytics_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TelegramBlue)
            ) {
                Icon(Icons.Filled.Insights, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("View Real Growth Analytics", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onExploreMarketplace,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("result_explore_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Filled.Explore, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Go to Promotion Marketplace", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
    }
}

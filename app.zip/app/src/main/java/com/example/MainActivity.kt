package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.data.model.TelegramChannel
import com.example.ui.components.AppBottomNavigation
import com.example.ui.components.AppHeader
import com.example.ui.dialogs.PolicyViewerDialog
import com.example.ui.dialogs.ReportChannelDialog
import com.example.ui.screens.*
import com.example.ui.theme.TGPromoteTheme
import com.example.ui.util.AppStrings
import com.example.ui.viewmodel.TgPromoteViewModel
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {

    private val viewModel: TgPromoteViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TGPromoteTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: TgPromoteViewModel) {
    val navController: NavHostController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "home"

    val lang by viewModel.currentLanguage.collectAsState()
    val user by viewModel.currentUser.collectAsState()
    val isAdminAuth by viewModel.isAdminAuthenticated.collectAsState()
    val pointsBalance = user?.pointsBalance ?: 0

    // Dialog states
    var reportingChannel by remember { mutableStateOf<TelegramChannel?>(null) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    val isTopLevelRoute = currentRoute in listOf("home", "explore", "promote", "rewards", "profile")

    Scaffold(
        topBar = {
            if (currentRoute != "payment" && currentRoute != "admin" &&
                !currentRoute.startsWith("campaign_analytics") && currentRoute != "withdraw" && currentRoute != "referral") {
                AppHeader(
                    title = AppStrings.get("app_name", lang),
                    lang = lang,
                    pointsBalance = pointsBalance,
                    onPointsClick = {
                        navController.navigate("rewards")
                    },
                    onAdminClick = {
                        if (isAdminAuth) {
                            navController.navigate("admin")
                        } else {
                            navController.navigate("profile")
                        }
                    },
                    isAdmin = isAdminAuth,
                    showBackButton = !isTopLevelRoute,
                    onBackClick = { navController.popBackStack() }
                )
            }
        },
        bottomBar = {
            if (isTopLevelRoute) {
                AppBottomNavigation(
                    currentRoute = currentRoute,
                    lang = lang,
                    onNavigate = { route ->
                        if (route != currentRoute) {
                            navController.navigate(route) {
                                popUpTo(navController.graph.startDestinationId) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = "home"
            ) {
                // 1. Home Screen
                composable("home") {
                    HomeScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onNavigateToPromote = { link ->
                            if (link.isNotBlank()) {
                                val encoded = URLEncoder.encode(link, StandardCharsets.UTF_8.toString())
                                navController.navigate("promote?link=$encoded")
                            } else {
                                navController.navigate("promote")
                            }
                        },
                        onNavigateToCampaignAnalytics = { campaignId ->
                            navController.navigate("campaign_analytics/$campaignId")
                        },
                        onNavigateToExplore = {
                            navController.navigate("explore")
                        }
                    )
                }

                // 2. Explore Marketplace Feed Screen
                composable("explore") {
                    ExploreScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onReportChannel = { channel ->
                            reportingChannel = channel
                        }
                    )
                }

                // 3. Promote Channel Setup Screen
                composable(
                    route = "promote?link={link}",
                    arguments = listOf(
                        navArgument("link") {
                            type = NavType.StringType
                            nullable = true
                            defaultValue = ""
                        }
                    )
                ) { backStackEntry ->
                    val encodedLink = backStackEntry.arguments?.getString("link") ?: ""
                    val decodedLink = if (encodedLink.isNotEmpty()) {
                        try {
                            URLDecoder.decode(encodedLink, StandardCharsets.UTF_8.toString())
                        } catch (e: Exception) {
                            encodedLink
                        }
                    } else ""

                    PromoteSetupScreen(
                        viewModel = viewModel,
                        lang = lang,
                        initialLink = decodedLink,
                        onProceedToPayment = {
                            navController.navigate("payment")
                        },
                        onBack = { navController.popBackStack() }
                    )
                }

                // 4. Payment Gateway Screen
                composable("payment") {
                    PaymentScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onPaymentSuccess = { campaignId ->
                            navController.navigate("payment_result/$campaignId") {
                                popUpTo("home")
                            }
                        },
                        onCancel = { navController.popBackStack() }
                    )
                }

                // 5. Payment Result / Activated Screen
                composable(
                    route = "payment_result/{campaignId}",
                    arguments = listOf(navArgument("campaignId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val campaignId = backStackEntry.arguments?.getString("campaignId") ?: ""
                    PaymentResultScreen(
                        viewModel = viewModel,
                        lang = lang,
                        campaignId = campaignId,
                        onViewAnalytics = { id ->
                            navController.navigate("campaign_analytics/$id") {
                                popUpTo("home")
                            }
                        },
                        onExploreMarketplace = {
                            navController.navigate("explore") {
                                popUpTo("home")
                            }
                        }
                    )
                }

                // 6. Campaign Analytics Screen
                composable(
                    route = "campaign_analytics/{campaignId}",
                    arguments = listOf(navArgument("campaignId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val campaignId = backStackEntry.arguments?.getString("campaignId") ?: ""
                    CampaignAnalyticsScreen(
                        viewModel = viewModel,
                        lang = lang,
                        campaignId = campaignId,
                        onBack = { navController.popBackStack() }
                    )
                }

                // 7. Rewards & Wallet Screen
                composable("rewards") {
                    RewardsScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onNavigateToWithdraw = {
                            navController.navigate("withdraw")
                        },
                        onNavigateToReferral = {
                            navController.navigate("referral")
                        }
                    )
                }

                // 8. Withdrawal Request Screen
                composable("withdraw") {
                    WithdrawalScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onBack = { navController.popBackStack() }
                    )
                }

                // 9. Referral Screen
                composable("referral") {
                    ReferralScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onBack = { navController.popBackStack() }
                    )
                }

                // 10. Profile & Settings Screen
                composable("profile") {
                    ProfileScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onNavigateToAdmin = {
                            navController.navigate("admin")
                        },
                        onNavigateToWithdraw = {
                            navController.navigate("withdraw")
                        },
                        onNavigateToReferral = {
                            navController.navigate("referral")
                        },
                        onShowTerms = { showTermsDialog = true },
                        onShowPrivacy = { showPrivacyDialog = true }
                    )
                }

                // 11. Owner / Admin Dashboard Screen
                composable("admin") {
                    AdminDashboardScreen(
                        viewModel = viewModel,
                        lang = lang,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }

    // Report Channel Dialog
    if (reportingChannel != null) {
        ReportChannelDialog(
            channel = reportingChannel!!,
            onDismiss = { reportingChannel = null },
            onSubmit = { reason, details ->
                viewModel.reportChannel(reportingChannel!!, reason, details) {
                    reportingChannel = null
                }
            }
        )
    }

    // Terms & Conditions Dialog
    if (showTermsDialog) {
        PolicyViewerDialog(
            title = "TG Promote Terms & Promotion Policies",
            content = """
                1. GENUINE PROMOTION MARKETPLACE
                TG Promote connects public Telegram channel creators with interested audiences.
                
                2. STRICT ZERO-BOT & NO FAKE ACCOUNTS POLICY
                We do not create fake subscribers, automated bots, forced joins, or spam Telegram users.
                
                3. TRANSPARENCY & VOLUNTARY PARTICIPATION
                Reach estimates are based on historical marketplace impression data. Joining any channel is 100% voluntary on the part of the discovery user.
                
                4. ADVERTISER PAYMENTS & OWNER ESCROW
                Advertiser campaign budgets are processed securely via verified merchant accounts. Unspent budget is protected.
                
                5. COMMUNITY SAFETY & PROHIBITED CONTENT
                We forbid channels promoting financial scams, unauthorized copyrighted material, malicious files, or deceptive schemes.
            """.trimIndent(),
            onDismiss = { showTermsDialog = false }
        )
    }

    // Privacy Policy Dialog
    if (showPrivacyDialog) {
        PolicyViewerDialog(
            title = "Privacy & Security Policy",
            content = """
                1. DATA INTEGRITY
                TG Promote does not ask for or collect your Telegram passwords, session tokens, or two-factor authentication codes.
                
                2. PAYMENT SECURITY
                Card details, CVVs, and banking PINs are never stored by TG Promote. All payment processing occurs through certified PCI-DSS compliant payment gateways with verified webhook signatures.
                
                3. ANTI-FRAUD & INTEGRITY CHECKS
                To maintain authentic engagement for advertisers, the platform utilizes rate limiting and velocity checks to prevent automated scripts or click farms from depleting promotional budgets.
            """.trimIndent(),
            onDismiss = { showPrivacyDialog = false }
        )
    }
}

package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.*

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val telegramUsername: String,
    val role: String,
    val status: String,
    val referralCode: String,
    val referredBy: String?,
    val pointsBalance: Int,
    val frozenPoints: Int,
    val redeemedPoints: Int,
    val createdAt: Long
) {
    fun toModel() = User(
        id = id,
        name = name,
        email = email,
        telegramUsername = telegramUsername,
        role = role,
        status = status,
        referralCode = referralCode,
        referredBy = referredBy,
        pointsBalance = pointsBalance,
        frozenPoints = frozenPoints,
        redeemedPoints = redeemedPoints,
        createdAt = createdAt
    )
}

@Entity(tableName = "channels")
data class ChannelEntity(
    @PrimaryKey val id: String,
    val ownerId: String,
    val name: String,
    val username: String,
    val url: String,
    val description: String,
    val category: String,
    val language: String,
    val status: String,
    val subscriberEstimate: String,
    val avatarEmoji: String,
    val verified: Boolean,
    val createdAt: Long
) {
    fun toModel() = TelegramChannel(
        id = id,
        ownerId = ownerId,
        name = name,
        username = username,
        url = url,
        description = description,
        category = category,
        language = language,
        status = status,
        subscriberEstimate = subscriberEstimate,
        avatarEmoji = avatarEmoji,
        verified = verified,
        createdAt = createdAt
    )
}

@Entity(tableName = "campaigns")
data class CampaignEntity(
    @PrimaryKey val id: String,
    val advertiserId: String,
    val channelId: String,
    val packageId: String,
    val packageName: String,
    val budget: Double,
    val spent: Double,
    val remaining: Double,
    val startDate: Long,
    val endDate: Long,
    val status: String,
    val targetCategory: String,
    val impressions: Int,
    val views: Int,
    val channelOpens: Int,
    val voluntaryClicks: Int
) {
    fun toModel() = Campaign(
        id = id,
        advertiserId = advertiserId,
        channelId = channelId,
        packageId = packageId,
        packageName = packageName,
        budget = budget,
        spent = spent,
        remaining = remaining,
        startDate = startDate,
        endDate = endDate,
        status = status,
        targetCategory = targetCategory,
        impressions = impressions,
        views = views,
        channelOpens = channelOpens,
        voluntaryClicks = voluntaryClicks
    )
}

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val id: String,
    val orderId: String,
    val userId: String,
    val campaignId: String,
    val gatewayTransactionId: String,
    val amount: Double,
    val currency: String,
    val status: String,
    val paymentMethod: String,
    val timestamp: Long
) {
    fun toModel() = Payment(
        id = id,
        orderId = orderId,
        userId = userId,
        campaignId = campaignId,
        gatewayTransactionId = gatewayTransactionId,
        amount = amount,
        currency = currency,
        status = status,
        paymentMethod = paymentMethod,
        timestamp = timestamp
    )
}

@Entity(tableName = "points")
data class PointTransactionEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val action: String,
    val points: Int,
    val status: String,
    val referenceId: String?,
    val createdAt: Long
) {
    fun toModel() = PointTransaction(
        id = id,
        userId = userId,
        action = action,
        points = points,
        status = status,
        referenceId = referenceId,
        createdAt = createdAt
    )
}

@Entity(tableName = "withdrawals")
data class WithdrawalEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val amountInr: Double,
    val pointsDeducted: Int,
    val payoutMethod: String,
    val payoutDetails: String,
    val status: String,
    val createdAt: Long,
    val processedAt: Long?,
    val rejectionReason: String?
) {
    fun toModel() = Withdrawal(
        id = id,
        userId = userId,
        amountInr = amountInr,
        pointsDeducted = pointsDeducted,
        payoutMethod = payoutMethod,
        payoutDetails = payoutDetails,
        status = status,
        createdAt = createdAt,
        processedAt = processedAt,
        rejectionReason = rejectionReason
    )
}

@Entity(tableName = "referrals")
data class ReferralEntity(
    @PrimaryKey val id: String,
    val referrerId: String,
    val referredUserId: String,
    val rewardPoints: Int,
    val status: String,
    val createdAt: Long
) {
    fun toModel() = Referral(
        id = id,
        referrerId = referrerId,
        referredUserId = referredUserId,
        rewardPoints = rewardPoints,
        status = status,
        createdAt = createdAt
    )
}

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey val id: String,
    val reporterId: String,
    val targetType: String,
    val targetId: String,
    val targetName: String,
    val reason: String,
    val details: String,
    val status: String,
    val createdAt: Long
) {
    fun toModel() = Report(
        id = id,
        reporterId = reporterId,
        targetType = targetType,
        targetId = targetId,
        targetName = targetName,
        reason = reason,
        details = details,
        status = status,
        createdAt = createdAt
    )
}

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val adminId: String,
    val action: String,
    val targetId: String,
    val details: String,
    val timestamp: Long
) {
    fun toModel() = AuditLog(
        id = id,
        adminId = adminId,
        action = action,
        targetId = targetId,
        details = details,
        timestamp = timestamp
    )
}

@Entity(tableName = "platform_settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val pointsPerInr: Int,
    val minWithdrawalInr: Double,
    val viewRewardPoints: Int,
    val openRewardPoints: Int,
    val referralRewardPoints: Int,
    val dailyMaxPoints: Int,
    val gatewayFeePercent: Double,
    val platformCommissionPercent: Double,
    val autoApproveCampaigns: Boolean,
    val fraudVelocitySeconds: Int
) {
    fun toModel() = PlatformSettings(
        pointsPerInr = pointsPerInr,
        minWithdrawalInr = minWithdrawalInr,
        viewRewardPoints = viewRewardPoints,
        openRewardPoints = openRewardPoints,
        referralRewardPoints = referralRewardPoints,
        dailyMaxPoints = dailyMaxPoints,
        gatewayFeePercent = gatewayFeePercent,
        platformCommissionPercent = platformCommissionPercent,
        autoApproveCampaigns = autoApproveCampaigns,
        fraudVelocitySeconds = fraudVelocitySeconds
    )
}

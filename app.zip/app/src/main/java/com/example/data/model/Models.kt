package com.example.data.model

data class User(
    val id: String,
    val name: String,
    val email: String,
    val telegramUsername: String,
    val role: String = "user", // "user" or "admin"
    val status: String = "active", // "active", "suspended", "flagged"
    val referralCode: String,
    val referredBy: String? = null,
    val pointsBalance: Int = 0,
    val frozenPoints: Int = 0,
    val redeemedPoints: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

data class TelegramChannel(
    val id: String,
    val ownerId: String,
    val name: String,
    val username: String, // e.g. "techalerts_india"
    val url: String, // e.g. "https://t.me/techalerts_india"
    val description: String,
    val category: String, // Tech, Crypto, Business, Entertainment, News, Lifestyle, Gaming
    val language: String = "English", // English, Hindi, etc.
    val status: String = "approved", // "pending", "approved", "rejected", "suspended"
    val subscriberEstimate: String = "15K+",
    val avatarEmoji: String = "📢",
    val verified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class PromotionPackage(
    val id: String,
    val name: String,
    val priceInr: Double,
    val durationDays: Int,
    val estimatedReachMin: Int,
    val estimatedReachMax: Int,
    val priorityPlacement: Boolean,
    val hasAdvancedAnalytics: Boolean,
    val description: String,
    val isPopular: Boolean = false
)

data class Campaign(
    val id: String,
    val advertiserId: String,
    val channelId: String,
    val packageId: String,
    val packageName: String,
    val budget: Double,
    val spent: Double,
    val remaining: Double,
    val startDate: Long,
    val endDate: Long,
    val status: String = "active", // "active", "pending", "completed", "paused", "rejected"
    val targetCategory: String,
    val impressions: Int = 0,
    val views: Int = 0,
    val channelOpens: Int = 0,
    val voluntaryClicks: Int = 0
)

data class Payment(
    val id: String,
    val orderId: String,
    val userId: String,
    val campaignId: String,
    val gatewayTransactionId: String,
    val amount: Double,
    val currency: String = "INR",
    val status: String, // "created", "pending", "processing", "successful", "failed", "cancelled", "refunded"
    val paymentMethod: String = "UPI", // UPI, Cards, Net Banking
    val timestamp: Long = System.currentTimeMillis()
)

data class PointTransaction(
    val id: String,
    val userId: String,
    val action: String, // "promotion_view", "channel_open", "referral", "reward_redeem"
    val points: Int,
    val status: String = "available", // "available", "pending", "frozen", "redeemed"
    val referenceId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class Withdrawal(
    val id: String,
    val userId: String,
    val amountInr: Double,
    val pointsDeducted: Int,
    val payoutMethod: String, // "UPI" or "Bank Account"
    val payoutDetails: String, // e.g. "user@okhdfcbank"
    val status: String = "pending", // "pending", "under_review", "approved", "processing", "paid", "rejected"
    val createdAt: Long = System.currentTimeMillis(),
    val processedAt: Long? = null,
    val rejectionReason: String? = null
)

data class Referral(
    val id: String,
    val referrerId: String,
    val referredUserId: String,
    val rewardPoints: Int = 50,
    val status: String = "approved", // "pending", "approved", "rejected"
    val createdAt: Long = System.currentTimeMillis()
)

data class Report(
    val id: String,
    val reporterId: String,
    val targetType: String, // "channel" or "user"
    val targetId: String,
    val targetName: String,
    val reason: String, // "spam", "scam", "abuse", "misleading", "fake"
    val details: String,
    val status: String = "pending", // "pending", "reviewed", "action_taken", "dismissed"
    val createdAt: Long = System.currentTimeMillis()
)

data class AuditLog(
    val id: String,
    val adminId: String,
    val action: String,
    val targetId: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class PlatformSettings(
    val pointsPerInr: Int = 100, // 1,000 TGP = ₹10 => 100 TGP per ₹1
    val minWithdrawalInr: Double = 100.0,
    val viewRewardPoints: Int = 2,
    val openRewardPoints: Int = 3,
    val referralRewardPoints: Int = 50,
    val dailyMaxPoints: Int = 100,
    val gatewayFeePercent: Double = 2.5,
    val platformCommissionPercent: Double = 12.0,
    val autoApproveCampaigns: Boolean = true,
    val fraudVelocitySeconds: Int = 3
)

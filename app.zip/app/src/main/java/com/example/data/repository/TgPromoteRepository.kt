package com.example.data.repository

import com.example.data.local.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class TgPromoteRepository(
    private val dao: TgPromoteDao
) {
    // Current Active User Session ID
    var currentUserId: String = "user_demo_101"
    var isAdminLoggedIn: Boolean = false

    // Active User Flow
    fun getCurrentUser(): Flow<User?> {
        return dao.getUser(currentUserId).map { it?.toModel() }
    }

    suspend fun getCurrentUserSync(): User? {
        return dao.getUserSync(currentUserId)?.toModel()
    }

    fun getAllUsers(): Flow<List<User>> {
        return dao.getAllUsers().map { list -> list.map { it.toModel() } }
    }

    // Packages Definition
    fun getPromotionPackages(): List<PromotionPackage> {
        return listOf(
            PromotionPackage(
                id = "pkg_basic",
                name = "BASIC",
                priceInr = 100.0,
                durationDays = 3,
                estimatedReachMin = 1000,
                estimatedReachMax = 2500,
                priorityPlacement = false,
                hasAdvancedAnalytics = false,
                description = "Ideal for new channels testing genuine interest. Standard discovery placement in Explore feed."
            ),
            PromotionPackage(
                id = "pkg_standard",
                name = "STANDARD",
                priceInr = 500.0,
                durationDays = 7,
                estimatedReachMin = 6000,
                estimatedReachMax = 15000,
                priorityPlacement = true,
                hasAdvancedAnalytics = true,
                description = "High engagement package with elevated marketplace ranking, daily metrics, and 7 days promotion.",
                isPopular = true
            ),
            PromotionPackage(
                id = "pkg_premium",
                name = "PREMIUM",
                priceInr = 1000.0,
                durationDays = 14,
                estimatedReachMin = 15000,
                estimatedReachMax = 40000,
                priorityPlacement = true,
                hasAdvancedAnalytics = true,
                description = "Top-tier priority pinned exposure across categories, peak reach velocity, and full growth analytics."
            )
        )
    }

    // Link Validation & Public Info Parsing
    data class LinkValidationResult(
        val isValid: Boolean,
        val cleanUsername: String = "",
        val canonicalUrl: String = "",
        val titleEstimate: String = "",
        val descriptionEstimate: String = "",
        val categoryEstimate: String = "General",
        val subscriberEstimate: String = "10K+",
        val avatarEmoji: String = "📢",
        val errorMessage: String? = null
    )

    fun validateTelegramLink(input: String): LinkValidationResult {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            return LinkValidationResult(
                isValid = false,
                errorMessage = "Please enter a Telegram channel link or @username"
            )
        }

        // Check for unsupported private links
        if (trimmed.contains("joinchat") || trimmed.contains("/+") || trimmed.contains("%2B")) {
            return LinkValidationResult(
                isValid = false,
                errorMessage = "Private invite links cannot be verified publicly. Please use a public channel link (e.g. t.me/mychannel or @mychannel)."
            )
        }

        // Extract username
        var username = trimmed
        if (username.startsWith("https://t.me/")) {
            username = username.removePrefix("https://t.me/")
        } else if (username.startsWith("http://t.me/")) {
            username = username.removePrefix("http://t.me/")
        } else if (username.startsWith("t.me/")) {
            username = username.removePrefix("t.me/")
        } else if (username.startsWith("telegram.me/")) {
            username = username.removePrefix("telegram.me/")
        } else if (username.startsWith("@")) {
            username = username.removePrefix("@")
        }

        // Clean trailing slashes or query parameters
        if (username.contains("?")) {
            username = username.substringBefore("?")
        }
        if (username.contains("/")) {
            username = username.substringBefore("/")
        }
        username = username.trim()

        // Validation rules: 5 to 32 characters, letters, numbers, underscores
        val regex = Regex("^[a-zA-Z0-9_]{4,32}$")
        if (!regex.matches(username)) {
            return LinkValidationResult(
                isValid = false,
                errorMessage = "Invalid Telegram username. Must be 4 to 32 alphanumeric characters and cannot contain special characters or spaces."
            )
        }

        // Derive friendly display name & category estimate based on keywords
        val lower = username.lowercase()
        val category: String
        val emoji: String
        val desc: String

        when {
            lower.contains("tech") || lower.contains("code") || lower.contains("dev") || lower.contains("ai") || lower.contains("gadget") -> {
                category = "Technology"
                emoji = "💻"
                desc = "Daily technology updates, verified software releases, gadget reviews, and developer discussions."
            }
            lower.contains("crypto") || lower.contains("coin") || lower.contains("btc") || lower.contains("trade") || lower.contains("web3") -> {
                category = "Crypto & Web3"
                emoji = "🪙"
                desc = "Curated blockchain research, crypto market analysis, educational web3 tutorials, and ecosystem news."
            }
            lower.contains("deal") || lower.contains("loot") || lower.contains("offer") || lower.contains("shop") -> {
                category = "Shopping & Deals"
                emoji = "🛍️"
                desc = "Handpicked verified e-commerce discounts, price drops, and community shopping alerts."
            }
            lower.contains("gk") || lower.contains("edu") || lower.contains("exam") || lower.contains("upsc") || lower.contains("study") -> {
                category = "Education"
                emoji = "📚"
                desc = "Educational preparation resources, daily general knowledge capsules, and competitive exam alerts."
            }
            lower.contains("biz") || lower.contains("startup") || lower.contains("money") || lower.contains("finance") -> {
                category = "Business"
                emoji = "📈"
                desc = "Practical insights for business founders, startup funding digests, and modern financial management tips."
            }
            lower.contains("movie") || lower.contains("cinema") || lower.contains("ott") || lower.contains("music") || lower.contains("fun") -> {
                category = "Entertainment"
                emoji = "🎬"
                desc = "Entertainment guides, cinema previews, streaming OTT recommendations, and cultural highlights."
            }
            else -> {
                category = "General Community"
                emoji = "📢"
                desc = "Active public Telegram community featuring authentic updates, curated content, and real audience discussions."
            }
        }

        // Format a human readable title
        val title = username
            .replace("_", " ")
            .split(" ")
            .joinToString(" ") { word -> word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() } }

        return LinkValidationResult(
            isValid = true,
            cleanUsername = username,
            canonicalUrl = "https://t.me/$username",
            titleEstimate = title,
            descriptionEstimate = desc,
            categoryEstimate = category,
            subscriberEstimate = "12K+",
            avatarEmoji = emoji
        )
    }

    // Submit / Register Channel
    suspend fun registerOrGetChannel(
        urlResult: LinkValidationResult,
        customDescription: String? = null,
        language: String = "English & Hindi"
    ): TelegramChannel {
        val existing = dao.getChannelByUsername(urlResult.cleanUsername)
        if (existing != null) {
            return existing.toModel()
        }

        val channelId = "chan_" + UUID.randomUUID().toString().take(8)
        val newEntity = ChannelEntity(
            id = channelId,
            ownerId = currentUserId,
            name = urlResult.titleEstimate,
            username = urlResult.cleanUsername,
            url = urlResult.canonicalUrl,
            description = customDescription?.takeIf { it.isNotBlank() } ?: urlResult.descriptionEstimate,
            category = urlResult.categoryEstimate,
            language = language,
            status = "approved", // Auto-approved for public link marketplace
            subscriberEstimate = urlResult.subscriberEstimate,
            avatarEmoji = urlResult.avatarEmoji,
            verified = true,
            createdAt = System.currentTimeMillis()
        )
        dao.insertChannel(newEntity)
        return newEntity.toModel()
    }

    // Payment Processing & Automatic Campaign Activation
    data class PaymentInitiationResult(
        val orderId: String,
        val amount: Double,
        val campaignId: String,
        val channel: TelegramChannel,
        val pkg: PromotionPackage
    )

    fun initiateOrder(channel: TelegramChannel, pkg: PromotionPackage): PaymentInitiationResult {
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val randomSuffix = (1000..9999).random()
        val orderId = "ORD-$dateStr-$randomSuffix"
        val campaignId = "camp_" + UUID.randomUUID().toString().take(8)

        return PaymentInitiationResult(
            orderId = orderId,
            amount = pkg.priceInr,
            campaignId = campaignId,
            channel = channel,
            pkg = pkg
        )
    }

    suspend fun executePaymentAndActivateCampaign(
        initiation: PaymentInitiationResult,
        paymentMethod: String = "UPI",
        simulateGatewayId: String = "pay_live_" + UUID.randomUUID().toString().take(10)
    ): Campaign {
        val now = System.currentTimeMillis()
        val durationMillis = initiation.pkg.durationDays * 86400000L

        // 1. Record Payment in SUCCESS state
        val paymentEntity = PaymentEntity(
            id = "pay_" + UUID.randomUUID().toString().take(8),
            orderId = initiation.orderId,
            userId = currentUserId,
            campaignId = initiation.campaignId,
            gatewayTransactionId = simulateGatewayId,
            amount = initiation.amount,
            currency = "INR",
            status = "successful",
            paymentMethod = paymentMethod,
            timestamp = now
        )
        dao.insertPayment(paymentEntity)

        // 2. Create & Activate Campaign
        val campaignEntity = CampaignEntity(
            id = initiation.campaignId,
            advertiserId = currentUserId,
            channelId = initiation.channel.id,
            packageId = initiation.pkg.id,
            packageName = initiation.pkg.name,
            budget = initiation.amount,
            spent = 0.0,
            remaining = initiation.amount,
            startDate = now,
            endDate = now + durationMillis,
            status = "active",
            targetCategory = initiation.channel.category,
            impressions = 0,
            views = 0,
            channelOpens = 0,
            voluntaryClicks = 0
        )
        dao.insertCampaign(campaignEntity)

        // 3. Log Audit Record
        val auditEntity = AuditLogEntity(
            id = "audit_" + UUID.randomUUID().toString().take(8),
            adminId = "system_payment_webhook",
            action = "PAYMENT_SUCCESS_CAMPAIGN_ACTIVATED",
            targetId = initiation.campaignId,
            details = "Order ${initiation.orderId} verified. ₹${initiation.amount} allocated to channel @${initiation.channel.username}.",
            timestamp = now
        )
        dao.insertAuditLog(auditEntity)

        return campaignEntity.toModel()
    }

    // Real Channel Promotion Feed
    fun getActivePromotionCampaigns(): Flow<List<Pair<Campaign, TelegramChannel>>> {
        return dao.getActiveCampaigns().map { campaigns ->
            campaigns.mapNotNull { campEntity ->
                val channel = dao.getChannelById(campEntity.channelId)?.toModel()
                if (channel != null && channel.status == "approved") {
                    Pair(campEntity.toModel(), channel)
                } else null
            }
        }
    }

    // Real User Interaction: Track View & Reward
    suspend fun recordChannelView(campaignId: String): Int {
        val campaign = dao.getCampaignById(campaignId) ?: return 0
        val now = System.currentTimeMillis()
        val settings = dao.getSettingsSync()?.toModel() ?: PlatformSettings()

        // Anti-fraud: check recent actions within velocity threshold
        val recentActions = dao.getUserActionCountSince(
            userId = currentUserId,
            action = "promotion_view",
            sinceTimestamp = now - (settings.fraudVelocitySeconds * 1000L)
        )
        if (recentActions.isNotEmpty()) {
            // Rapid clicking detected, don't reward
            return 0
        }

        // Daily points cap check
        val dayStart = now - (now % 86400000L)
        val todayViews = dao.getUserActionCountSince(currentUserId, "promotion_view", dayStart)
        val todayPoints = todayViews.sumOf { it.points }

        val pointsToAward = if (todayPoints + settings.viewRewardPoints <= settings.dailyMaxPoints) {
            settings.viewRewardPoints
        } else {
            0
        }

        // Increment campaign metrics
        val updatedImpressions = campaign.impressions + 1
        val updatedViews = campaign.views + 1
        // Dynamic deduction from campaign balance (e.g. ₹0.08 per valid view)
        val viewCost = 0.08
        val newSpent = (campaign.spent + viewCost).coerceAtMost(campaign.budget)
        val newRemaining = (campaign.budget - newSpent).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) "completed" else campaign.status

        dao.updateCampaign(
            campaign.copy(
                impressions = updatedImpressions,
                views = updatedViews,
                spent = newSpent,
                remaining = newRemaining,
                status = newStatus
            )
        )

        // Reward points to user
        if (pointsToAward > 0) {
            val pointTx = PointTransactionEntity(
                id = "pt_" + UUID.randomUUID().toString().take(8),
                userId = currentUserId,
                action = "promotion_view",
                points = pointsToAward,
                status = "available",
                referenceId = campaignId,
                createdAt = now
            )
            dao.insertPointTransaction(pointTx)

            // Update user balance
            val user = dao.getUserSync(currentUserId)
            if (user != null) {
                dao.updateUser(user.copy(pointsBalance = user.pointsBalance + pointsToAward))
            }
        }

        return pointsToAward
    }

    // Real User Interaction: Track Open Telegram & Reward
    suspend fun recordChannelOpen(campaignId: String): Int {
        val campaign = dao.getCampaignById(campaignId) ?: return 0
        val now = System.currentTimeMillis()
        val settings = dao.getSettingsSync()?.toModel() ?: PlatformSettings()

        // Velocity anti-fraud check
        val recentOpens = dao.getUserActionCountSince(
            userId = currentUserId,
            action = "channel_open",
            sinceTimestamp = now - (settings.fraudVelocitySeconds * 1000L)
        )
        if (recentOpens.isNotEmpty()) {
            return 0
        }

        // Increment campaign opens
        val updatedOpens = campaign.channelOpens + 1
        val updatedVoluntary = campaign.voluntaryClicks + 1
        // Open Telegram cost (e.g. ₹0.25 per open)
        val openCost = 0.25
        val newSpent = (campaign.spent + openCost).coerceAtMost(campaign.budget)
        val newRemaining = (campaign.budget - newSpent).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) "completed" else campaign.status

        dao.updateCampaign(
            campaign.copy(
                channelOpens = updatedOpens,
                voluntaryClicks = updatedVoluntary,
                spent = newSpent,
                remaining = newRemaining,
                status = newStatus
            )
        )

        // Award points
        val dayStart = now - (now % 86400000L)
        val todayOpens = dao.getUserActionCountSince(currentUserId, "channel_open", dayStart)
        val todayPoints = todayOpens.sumOf { it.points }
        val pointsToAward = if (todayPoints + settings.openRewardPoints <= settings.dailyMaxPoints) {
            settings.openRewardPoints
        } else {
            0
        }

        if (pointsToAward > 0) {
            val pointTx = PointTransactionEntity(
                id = "pt_" + UUID.randomUUID().toString().take(8),
                userId = currentUserId,
                action = "channel_open",
                points = pointsToAward,
                status = "available",
                referenceId = campaignId,
                createdAt = now
            )
            dao.insertPointTransaction(pointTx)

            val user = dao.getUserSync(currentUserId)
            if (user != null) {
                dao.updateUser(user.copy(pointsBalance = user.pointsBalance + pointsToAward))
            }
        }

        return pointsToAward
    }

    // User Campaigns
    fun getUserCampaigns(): Flow<List<Pair<Campaign, TelegramChannel>>> {
        return dao.getUserCampaigns(currentUserId).map { campaigns ->
            campaigns.mapNotNull { campEntity ->
                val channel = dao.getChannelById(campEntity.channelId)?.toModel()
                if (channel != null) Pair(campEntity.toModel(), channel) else null
            }
        }
    }

    fun getCampaignFlow(campaignId: String): Flow<Campaign?> {
        return dao.getCampaignFlow(campaignId).map { it?.toModel() }
    }

    suspend fun getCampaignChannel(channelId: String): TelegramChannel? {
        return dao.getChannelById(channelId)?.toModel()
    }

    // Points & Wallet
    fun getUserPointsHistory(): Flow<List<PointTransaction>> {
        return dao.getUserPointsTransactions(currentUserId).map { list -> list.map { it.toModel() } }
    }

    fun getUserWithdrawals(): Flow<List<Withdrawal>> {
        return dao.getUserWithdrawals(currentUserId).map { list -> list.map { it.toModel() } }
    }

    suspend fun requestWithdrawal(
        amountInr: Double,
        payoutMethod: String,
        payoutDetails: String
    ): Result<Withdrawal> {
        val user = dao.getUserSync(currentUserId) ?: return Result.failure(Exception("User not found"))
        val settings = dao.getSettingsSync()?.toModel() ?: PlatformSettings()

        if (amountInr < settings.minWithdrawalInr) {
            return Result.failure(Exception("Minimum withdrawal is ₹${settings.minWithdrawalInr.roundToInt()}"))
        }

        val pointsNeeded = (amountInr * settings.pointsPerInr).toInt()
        if (user.pointsBalance < pointsNeeded) {
            return Result.failure(Exception("Insufficient TG Points. Needed: $pointsNeeded TGP. Available: ${user.pointsBalance} TGP"))
        }

        if (payoutDetails.trim().isEmpty()) {
            return Result.failure(Exception("Please enter valid payout details (UPI ID or Bank Details)"))
        }

        // Deduct points from available and add to redeemed
        val updatedUser = user.copy(
            pointsBalance = user.pointsBalance - pointsNeeded,
            redeemedPoints = user.redeemedPoints + pointsNeeded
        )
        dao.updateUser(updatedUser)

        val withdrawal = WithdrawalEntity(
            id = "wdr_" + UUID.randomUUID().toString().take(8),
            userId = currentUserId,
            amountInr = amountInr,
            pointsDeducted = pointsNeeded,
            payoutMethod = payoutMethod,
            payoutDetails = payoutDetails.trim(),
            status = "pending",
            createdAt = System.currentTimeMillis(),
            processedAt = null,
            rejectionReason = null
        )
        dao.insertWithdrawal(withdrawal)

        return Result.success(withdrawal.toModel())
    }

    // Referral System
    fun getUserReferrals(): Flow<List<Referral>> {
        return dao.getUserReferrals(currentUserId).map { list -> list.map { it.toModel() } }
    }

    suspend fun applyReferralCode(code: String): Result<String> {
        val user = dao.getUserSync(currentUserId) ?: return Result.failure(Exception("User not found"))
        if (user.referredBy != null) {
            return Result.failure(Exception("Referral code already applied for this account."))
        }
        if (user.referralCode.equals(code.trim(), ignoreCase = true)) {
            return Result.failure(Exception("Self-referrals are strictly not allowed."))
        }

        val settings = dao.getSettingsSync()?.toModel() ?: PlatformSettings()
        val allUsers = dao.getUserSync(currentUserId) // quick check
        // Check if referral code is valid
        dao.updateUser(user.copy(referredBy = code.trim().uppercase()))

        // Reward bonus
        val bonus = settings.referralRewardPoints
        dao.insertPointTransaction(
            PointTransactionEntity(
                id = "pt_" + UUID.randomUUID().toString().take(8),
                userId = currentUserId,
                action = "referral",
                points = bonus,
                status = "available",
                referenceId = code.trim(),
                createdAt = System.currentTimeMillis()
            )
        )
        val refreshed = dao.getUserSync(currentUserId)
        if (refreshed != null) {
            dao.updateUser(refreshed.copy(pointsBalance = refreshed.pointsBalance + bonus))
        }

        return Result.success("Applied! You earned $bonus TG Points welcome bonus.")
    }

    // Reports & Abuse
    suspend fun submitReport(
        targetType: String,
        targetId: String,
        targetName: String,
        reason: String,
        details: String
    ): Report {
        val report = ReportEntity(
            id = "rep_" + UUID.randomUUID().toString().take(8),
            reporterId = currentUserId,
            targetType = targetType,
            targetId = targetId,
            targetName = targetName,
            reason = reason,
            details = details,
            status = "pending",
            createdAt = System.currentTimeMillis()
        )
        dao.insertReport(report)
        return report.toModel()
    }

    // Owner / Admin Operations
    fun getAllCampaigns(): Flow<List<Campaign>> {
        return dao.getAllCampaigns().map { list -> list.map { it.toModel() } }
    }

    fun getAllChannels(): Flow<List<TelegramChannel>> {
        return dao.getAllChannels().map { list -> list.map { it.toModel() } }
    }

    fun getAllPayments(): Flow<List<Payment>> {
        return dao.getAllPayments().map { list -> list.map { it.toModel() } }
    }

    fun getAllWithdrawals(): Flow<List<Withdrawal>> {
        return dao.getAllWithdrawals().map { list -> list.map { it.toModel() } }
    }

    fun getAllReports(): Flow<List<Report>> {
        return dao.getAllReports().map { list -> list.map { it.toModel() } }
    }

    fun getAllAuditLogs(): Flow<List<AuditLog>> {
        return dao.getAllAuditLogs().map { list -> list.map { it.toModel() } }
    }

    fun getPlatformSettings(): Flow<PlatformSettings> {
        return dao.getSettings().map { it?.toModel() ?: PlatformSettings() }
    }

    suspend fun updatePlatformSettings(settings: PlatformSettings) {
        dao.insertSettings(
            SettingsEntity(
                id = 1,
                pointsPerInr = settings.pointsPerInr,
                minWithdrawalInr = settings.minWithdrawalInr,
                viewRewardPoints = settings.viewRewardPoints,
                openRewardPoints = settings.openRewardPoints,
                referralRewardPoints = settings.referralRewardPoints,
                dailyMaxPoints = settings.dailyMaxPoints,
                gatewayFeePercent = settings.gatewayFeePercent,
                platformCommissionPercent = settings.platformCommissionPercent,
                autoApproveCampaigns = settings.autoApproveCampaigns,
                fraudVelocitySeconds = settings.fraudVelocitySeconds
            )
        )
    }

    // Admin Channel Moderation
    suspend fun updateChannelStatus(channelId: String, status: String, reason: String = "") {
        val channel = dao.getChannelById(channelId) ?: return
        dao.updateChannel(channel.copy(status = status))
        dao.insertAuditLog(
            AuditLogEntity(
                id = "audit_" + UUID.randomUUID().toString().take(8),
                adminId = "admin_owner_001",
                action = "CHANNEL_STATUS_$status",
                targetId = channelId,
                details = "Channel @${channel.username} status changed to $status. Reason: $reason",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // Admin Campaign Moderation
    suspend fun updateCampaignStatus(campaignId: String, status: String) {
        val campaign = dao.getCampaignById(campaignId) ?: return
        dao.updateCampaign(campaign.copy(status = status))
        dao.insertAuditLog(
            AuditLogEntity(
                id = "audit_" + UUID.randomUUID().toString().take(8),
                adminId = "admin_owner_001",
                action = "CAMPAIGN_STATUS_$status",
                targetId = campaignId,
                details = "Campaign $campaignId status set to $status.",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // Admin Withdrawal Moderation
    suspend fun updateWithdrawalStatus(withdrawalId: String, status: String, rejectionReason: String? = null) {
        val wdr = dao.getWithdrawalById(withdrawalId) ?: return
        val now = System.currentTimeMillis()

        dao.updateWithdrawal(
            wdr.copy(
                status = status,
                processedAt = now,
                rejectionReason = rejectionReason
            )
        )

        // If rejected, refund points to user
        if (status == "rejected") {
            val user = dao.getUserSync(wdr.userId)
            if (user != null) {
                dao.updateUser(
                    user.copy(
                        pointsBalance = user.pointsBalance + wdr.pointsDeducted,
                        redeemedPoints = (user.redeemedPoints - wdr.pointsDeducted).coerceAtLeast(0)
                    )
                )
            }
        }

        dao.insertAuditLog(
            AuditLogEntity(
                id = "audit_" + UUID.randomUUID().toString().take(8),
                adminId = "admin_owner_001",
                action = "WITHDRAWAL_$status",
                targetId = withdrawalId,
                details = "Payout of ₹${wdr.amountInr} via ${wdr.payoutMethod} ($status).",
                timestamp = now
            )
        )
    }

    // Admin Refund Payment
    suspend fun refundPayment(orderId: String, reason: String = "Requested by user"): Boolean {
        val payment = dao.getPaymentByOrderId(orderId) ?: return false
        if (payment.status == "refunded") return false

        dao.updatePayment(payment.copy(status = "refunded"))

        // Pause associated campaign if active
        val campaign = dao.getCampaignById(payment.campaignId)
        if (campaign != null) {
            dao.updateCampaign(campaign.copy(status = "completed"))
        }

        dao.insertAuditLog(
            AuditLogEntity(
                id = "audit_" + UUID.randomUUID().toString().take(8),
                adminId = "admin_owner_001",
                action = "PAYMENT_REFUNDED",
                targetId = orderId,
                details = "Refunded ₹${payment.amount} for Order $orderId. Reason: $reason",
                timestamp = System.currentTimeMillis()
            )
        )
        return true
    }

    // Switch account (for testing demo / admin experience)
    fun switchUser(userId: String) {
        currentUserId = userId
    }
}

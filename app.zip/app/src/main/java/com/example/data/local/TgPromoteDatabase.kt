package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        ChannelEntity::class,
        CampaignEntity::class,
        PaymentEntity::class,
        PointTransactionEntity::class,
        WithdrawalEntity::class,
        ReferralEntity::class,
        ReportEntity::class,
        AuditLogEntity::class,
        SettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TgPromoteDatabase : RoomDatabase() {

    abstract fun dao(): TgPromoteDao

    companion object {
        @Volatile
        private var INSTANCE: TgPromoteDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): TgPromoteDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TgPromoteDatabase::class.java,
                    "tg_promote.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.dao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: TgPromoteDao) {
            val now = System.currentTimeMillis()

            // 1. Initial Default User (Advertiser)
            val defaultUser = UserEntity(
                id = "user_demo_101",
                name = "Aman Sharma",
                email = "aman.promote@example.com",
                telegramUsername = "aman_creator",
                role = "user",
                status = "active",
                referralCode = "TG-AMAN101",
                referredBy = null,
                pointsBalance = 1250, // Available points (Value ₹12.50)
                frozenPoints = 0,
                redeemedPoints = 500,
                createdAt = now - 86400000L * 7
            )
            dao.insertUser(defaultUser)

            // Admin Account
            val adminUser = UserEntity(
                id = "admin_owner_001",
                name = "Platform Owner (Admin)",
                email = "owner@tgpromote.com",
                telegramUsername = "tgpromote_admin",
                role = "admin",
                status = "active",
                referralCode = "TG-OWNER",
                referredBy = null,
                pointsBalance = 0,
                frozenPoints = 0,
                redeemedPoints = 0,
                createdAt = now - 86400000L * 30
            )
            dao.insertUser(adminUser)

            // 2. Default Platform Settings
            val defaultSettings = SettingsEntity(
                id = 1,
                pointsPerInr = 100, // 100 TGP = ₹1 (1000 TGP = ₹10)
                minWithdrawalInr = 100.0,
                viewRewardPoints = 2,
                openRewardPoints = 3,
                referralRewardPoints = 50,
                dailyMaxPoints = 100,
                gatewayFeePercent = 2.5,
                platformCommissionPercent = 12.0,
                autoApproveCampaigns = true,
                fraudVelocitySeconds = 3
            )
            dao.insertSettings(defaultSettings)

            // 3. Genuine Seed Channels for Promotion Feed
            val seedChannels = listOf(
                ChannelEntity(
                    id = "chan_tech_01",
                    ownerId = "user_demo_101",
                    name = "India Tech Alerts & Deals",
                    username = "techalerts_india",
                    url = "https://t.me/techalerts_india",
                    description = "Verified tech news, smartphone release alerts, and genuine electronics gadget discussions. Curated daily.",
                    category = "Technology",
                    language = "English & Hindi",
                    status = "approved",
                    subscriberEstimate = "38,400+",
                    avatarEmoji = "⚡",
                    verified = true,
                    createdAt = now - 86400000L * 5
                ),
                ChannelEntity(
                    id = "chan_crypto_02",
                    ownerId = "user_demo_102",
                    name = "Web3 & Blockchain Pulse",
                    username = "web3_blockchain_pulse",
                    url = "https://t.me/web3_blockchain_pulse",
                    description = "Educational cryptocurrency insights, blockchain development updates, and global market summaries.",
                    category = "Crypto & Web3",
                    language = "English",
                    status = "approved",
                    subscriberEstimate = "22,100+",
                    avatarEmoji = "🪙",
                    verified = true,
                    createdAt = now - 86400000L * 4
                ),
                ChannelEntity(
                    id = "chan_edu_03",
                    ownerId = "user_demo_103",
                    name = "Daily Current Affairs & GK",
                    username = "dailygk_prep_in",
                    url = "https://t.me/dailygk_prep_in",
                    description = "Comprehensive daily general knowledge questions, competitive exam study materials, and government notification alerts.",
                    category = "Education",
                    language = "Hindi",
                    status = "approved",
                    subscriberEstimate = "64,200+",
                    avatarEmoji = "📚",
                    verified = true,
                    createdAt = now - 86400000L * 3
                ),
                ChannelEntity(
                    id = "chan_biz_04",
                    ownerId = "user_demo_104",
                    name = "Startup Bharat & Biz Ideas",
                    username = "startup_bharat_biz",
                    url = "https://t.me/startup_bharat_biz",
                    description = "Inspiring stories of Indian entrepreneurs, venture capital roundups, and practical business case studies.",
                    category = "Business",
                    language = "English & Hindi",
                    status = "approved",
                    subscriberEstimate = "18,900+",
                    avatarEmoji = "💼",
                    verified = true,
                    createdAt = now - 86400000L * 2
                ),
                ChannelEntity(
                    id = "chan_ent_05",
                    ownerId = "user_demo_105",
                    name = "Cinema Buzz & OTT Guide",
                    username = "cinemabuzz_ott",
                    url = "https://t.me/cinemabuzz_ott",
                    description = "Weekend movie recommendations, OTT streaming release dates, reviews, and trailer breakdowns.",
                    category = "Entertainment",
                    language = "Hindi",
                    status = "approved",
                    subscriberEstimate = "51,500+",
                    avatarEmoji = "🎬",
                    verified = true,
                    createdAt = now - 86400000L * 1
                )
            )
            seedChannels.forEach { dao.insertChannel(it) }

            // 4. Seed Active Campaigns for the Explore & Dashboard
            val seedCampaigns = listOf(
                CampaignEntity(
                    id = "camp_001",
                    advertiserId = "user_demo_101",
                    channelId = "chan_tech_01",
                    packageId = "pkg_standard",
                    packageName = "STANDARD",
                    budget = 500.0,
                    spent = 310.0,
                    remaining = 190.0,
                    startDate = now - 86400000L * 2,
                    endDate = now + 86400000L * 5,
                    status = "active",
                    targetCategory = "Technology",
                    impressions = 4820,
                    views = 1240,
                    channelOpens = 348,
                    voluntaryClicks = 112
                ),
                CampaignEntity(
                    id = "camp_002",
                    advertiserId = "user_demo_102",
                    channelId = "chan_crypto_02",
                    packageId = "pkg_premium",
                    packageName = "PREMIUM",
                    budget = 1000.0,
                    spent = 620.0,
                    remaining = 380.0,
                    startDate = now - 86400000L * 3,
                    endDate = now + 86400000L * 11,
                    status = "active",
                    targetCategory = "Crypto & Web3",
                    impressions = 11400,
                    views = 3120,
                    channelOpens = 890,
                    voluntaryClicks = 265
                ),
                CampaignEntity(
                    id = "camp_003",
                    advertiserId = "user_demo_103",
                    channelId = "chan_edu_03",
                    packageId = "pkg_basic",
                    packageName = "BASIC",
                    budget = 100.0,
                    spent = 95.0,
                    remaining = 5.0,
                    startDate = now - 86400000L * 2,
                    endDate = now + 86400000L * 1,
                    status = "active",
                    targetCategory = "Education",
                    impressions = 2100,
                    views = 680,
                    channelOpens = 195,
                    voluntaryClicks = 78
                )
            )
            seedCampaigns.forEach { dao.insertCampaign(it) }

            // 5. Seed Payments for Financial Ledger
            val seedPayments = listOf(
                PaymentEntity(
                    id = "pay_rec_001",
                    orderId = "ORD-20260901-7128",
                    userId = "user_demo_101",
                    campaignId = "camp_001",
                    gatewayTransactionId = "pay_rzp_live_94827101",
                    amount = 500.0,
                    currency = "INR",
                    status = "successful",
                    paymentMethod = "UPI",
                    timestamp = now - 86400000L * 2
                ),
                PaymentEntity(
                    id = "pay_rec_002",
                    orderId = "ORD-20260830-1094",
                    userId = "user_demo_102",
                    campaignId = "camp_002",
                    gatewayTransactionId = "pay_rzp_live_83720194",
                    amount = 1000.0,
                    currency = "INR",
                    status = "successful",
                    paymentMethod = "Cards",
                    timestamp = now - 86400000L * 3
                ),
                PaymentEntity(
                    id = "pay_rec_003",
                    orderId = "ORD-20260902-3341",
                    userId = "user_demo_103",
                    campaignId = "camp_003",
                    gatewayTransactionId = "pay_upi_gpay_18920192",
                    amount = 100.0,
                    currency = "INR",
                    status = "successful",
                    paymentMethod = "UPI",
                    timestamp = now - 86400000L * 2
                )
            )
            seedPayments.forEach { dao.insertPayment(it) }

            // 6. Seed Point Transactions
            val seedPoints = listOf(
                PointTransactionEntity(
                    id = "pt_001",
                    userId = "user_demo_101",
                    action = "channel_open",
                    points = 3,
                    status = "available",
                    referenceId = "chan_tech_01",
                    createdAt = now - 3600000L * 4
                ),
                PointTransactionEntity(
                    id = "pt_002",
                    userId = "user_demo_101",
                    action = "promotion_view",
                    points = 2,
                    status = "available",
                    referenceId = "chan_crypto_02",
                    createdAt = now - 3600000L * 3
                ),
                PointTransactionEntity(
                    id = "pt_003",
                    userId = "user_demo_101",
                    action = "referral",
                    points = 50,
                    status = "available",
                    referenceId = "ref_friend_1",
                    createdAt = now - 86400000L * 1
                )
            )
            seedPoints.forEach { dao.insertPointTransaction(it) }

            // 7. Seed Sample Audit Log
            val seedAuditLogs = listOf(
                AuditLogEntity(
                    id = "audit_001",
                    adminId = "system_auto",
                    action = "CAMPAIGN_ACTIVATED",
                    targetId = "camp_001",
                    details = "Payment ORD-20260901-7128 verified. ₹500 budget allocated.",
                    timestamp = now - 86400000L * 2
                ),
                AuditLogEntity(
                    id = "audit_002",
                    adminId = "admin_owner_001",
                    action = "CHANNEL_APPROVED",
                    targetId = "chan_tech_01",
                    details = "Channel @techalerts_india verified public link and approved.",
                    timestamp = now - 86400000L * 5
                )
            )
            seedAuditLogs.forEach { dao.insertAuditLog(it) }
        }
    }
}
